
export enum UserType {
  BUDGET = 'Essential',
  NOMAD = 'Explorer',
  PREMIUM = 'Premium'
}

export enum UserRole {
  TRAVELER = 'traveler',
  ADMIN = 'admin'
}

export type ConciergePersona = 'professional' | 'friendly' | 'scout';
export type TravelMood = 'chill' | 'productive' | 'adventure' | 'local';

export interface Citation {
  uri: string;
  title: string;
}

export interface UserProfile {
  name: string;
  email: string;
  type: UserType;
  role: UserRole;
  loyaltyPoints: number;
  persona: ConciergePersona;
  currentMood: TravelMood;
  preferences: {
    budget: 'low' | 'medium' | 'high';
    travelStyle: 'adventure' | 'relaxation' | 'cultural' | 'business';
    foodPreference: string;
    needsWifi: boolean;
  };
  history: string[]; 
}

export interface VisualScoutResult {
  identification: string;
  context: string;
  advice: string;
}

export interface TransportOption {
  id: string;
  type: 'flight' | 'train' | 'bus' | 'cab';
  provider: string;
  providerLogo?: string;
  cost: number;
  duration: string;
  departureTime: string;
  arrivalTime: string;
  stops: number;
  comfortRating: number;
  isFastest: boolean;
  isCheapest: boolean;
  emissions?: string;
}

export interface ItineraryItem {
  time: string;
  activity: string;
  type: 'food' | 'sightseeing' | 'transport' | 'rest' | 'business';
  location?: string;
}

export interface ItineraryDay {
  day: number;
  date: string;
  items: ItineraryItem[];
  weatherForecast: string;
  crowdLevel: 'low' | 'medium' | 'high';
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export enum AppView {
  LOGIN = 'login',
  DASHBOARD = 'dashboard',
  PLANNER = 'planner',
  EXPLORER = 'explorer',
  PROFILE = 'profile',
  CHAT = 'chat',
  PREMIUM = 'premium',
  COMPANY_DASHBOARD = 'company_dashboard',
  COMPANY_ANALYTICS = 'company_analytics',
  GROUP_BOOKING = 'group_booking',
  TRANSLATOR = 'live_translator',
  TOUR = 'cinematic_tour',
  SAFETY = 'safety_radar',
  PACKING = 'packing_scout'
}
