import React, { useState, useEffect, useMemo, useCallback } from 'react';
import Layout from './components/Layout';
import Login from './components/Login';
import Planner from './components/Planner';
import Dashboard from './components/Dashboard';
import Explorer from './components/Explorer';
import Premium from './components/Premium';
import Profile from './components/Profile';
import CompanyDashboard from './components/CompanyDashboard';
import GroupBooking from './components/GroupBooking';
import LiveConcierge from './components/LiveConcierge';
import VideoTour from './components/VideoTour';
import SafetyRadar from './components/SafetyRadar';
import PackingScout from './components/PackingScout';
import { AppView, UserType, UserProfile, UserRole } from './types';

const App: React.FC = () => {
  // Temporarily set to true to focus on the main application features
  const [isLoggedIn, setIsLoggedIn] = useState(true);
  const [currentView, setCurrentView] = useState<AppView>(AppView.DASHBOARD);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(() => {
    return document.documentElement.classList.contains('dark');
  });
  
  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => document.removeEventListener('fullscreenchange', handleFullscreenChange);
  }, []);

  const toggleTheme = useCallback(() => {
    setIsDarkMode(prev => {
      const next = !prev;
      if (next) {
        document.documentElement.classList.add('dark');
        document.body.classList.add('dark');
        document.body.classList.remove('light');
      } else {
        document.documentElement.classList.remove('dark');
        document.body.classList.remove('dark');
        document.body.classList.add('light');
      }
      return next;
    });
  }, []);

  const [plannerDestination, setPlannerDestination] = useState('');
  const [plannerOrigin, setPlannerOrigin] = useState('Mumbai, IN');
  const [globalLocation, setGlobalLocation] = useState('Mumbai, India');
  
  const defaultUser: UserProfile = useMemo(() => ({
    name: "Alex Wanderer",
    email: "alex@wanderer.travel",
    type: UserType.NOMAD,
    role: UserRole.TRAVELER,
    loyaltyPoints: 12500,
    persona: 'scout',
    currentMood: 'adventure',
    preferences: {
      budget: 'medium',
      travelStyle: 'adventure',
      foodPreference: 'local street food',
      needsWifi: true
    },
    history: ['Bali', 'Lisbon', 'Mexico City']
  }), []);

  const [user, setUser] = useState<UserProfile>(defaultUser);

  const handleLogin = useCallback((role: UserRole) => {
      setUser({ ...defaultUser, role });
      setIsLoggedIn(true);
      setCurrentView(role === UserRole.ADMIN ? AppView.COMPANY_DASHBOARD : AppView.DASHBOARD);
  }, [defaultUser]);

  const handleSignup = useCallback((profileData: Partial<UserProfile>) => {
      setUser({ ...defaultUser, ...profileData });
      setIsLoggedIn(true);
      setCurrentView(AppView.DASHBOARD);
  }, [defaultUser]);

  const handleLogout = useCallback(() => {
      setIsLoggedIn(false);
      setCurrentView(AppView.LOGIN);
  }, []);

  const handlePlanTrip = useCallback((destination: string, origin?: string) => {
      setPlannerDestination(destination);
      if (origin) setPlannerOrigin(origin);
      setGlobalLocation(destination);
      setCurrentView(AppView.PLANNER);
  }, []);

  const handleUpgrade = useCallback((type: UserType) => {
      setUser(prev => ({ ...prev, type }));
      setCurrentView(AppView.DASHBOARD);
  }, []);

  const updateProfile = useCallback((data: Partial<UserProfile>) => {
      setUser(prev => ({ ...prev, ...data }));
  }, []);

  const changeView = useCallback((view: AppView) => setCurrentView(view), []);

  if (!isLoggedIn) {
      return (
        <Login 
          onLogin={handleLogin} 
          onSignup={handleSignup} 
          isDarkMode={isDarkMode} 
          onToggleTheme={toggleTheme} 
        />
      );
  }

  const renderContent = () => {
    switch (currentView) {
      case AppView.DASHBOARD: 
        return <Dashboard user={user} onUpdateProfile={updateProfile} onChangeView={changeView} onPlanTrip={handlePlanTrip} isFullscreen={isFullscreen} />;
      case AppView.PLANNER: 
        return <Planner initialDestination={plannerDestination} initialOrigin={plannerOrigin} user={user} />;
      case AppView.EXPLORER: 
        return <Explorer defaultLocation={globalLocation} />;
      case AppView.PREMIUM: 
        return <Premium currentType={user.type} onUpgrade={handleUpgrade} />;
      case AppView.PROFILE: 
        return <Profile user={user} onUpdate={updateProfile} />;
      case AppView.COMPANY_DASHBOARD:
        return <CompanyDashboard />;
      case AppView.GROUP_BOOKING:
        return <GroupBooking />;
      case AppView.TRANSLATOR:
        return <LiveConcierge user={user} onBack={() => changeView(AppView.DASHBOARD)} />;
      case AppView.TOUR:
        return <VideoTour destination={plannerDestination || 'Bali'} onBack={() => changeView(AppView.DASHBOARD)} />;
      case AppView.SAFETY:
        return <SafetyRadar location={plannerDestination || globalLocation} onBack={() => changeView(AppView.DASHBOARD)} />;
      case AppView.PACKING:
        return <PackingScout destination={plannerDestination || 'Bali'} duration={7} user={user} onBack={() => changeView(AppView.DASHBOARD)} />;
      default: 
        return <Dashboard user={user} onUpdateProfile={updateProfile} onChangeView={changeView} onPlanTrip={handlePlanTrip} isFullscreen={isFullscreen} />;
    }
  };

  return (
    <Layout 
      currentView={currentView} 
      onChangeView={changeView} 
      user={user} 
      onLogout={handleLogout}
      isDarkMode={isDarkMode}
      onToggleTheme={toggleTheme}
      isFullscreen={isFullscreen}
    >
      <div className="aura-layer">
        <div className="absolute top-0 -left-1/4 w-[80%] h-[80%] rounded-full animate-aura-drift opacity-20 bg-indigo-600 transition-colors duration-1000"></div>
        <div className="absolute bottom-0 -right-1/4 w-[80%] h-[80%] rounded-full animate-aura-drift opacity-20 bg-amber-600 transition-colors duration-1000" style={{ animationDirection: 'reverse', animationDuration: '25s' }}></div>
      </div>
      {renderContent()}
    </Layout>
  );
};

export default App;