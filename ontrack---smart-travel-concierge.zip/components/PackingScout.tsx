
import React, { useState, useEffect } from 'react';
import { ShoppingBag, CheckCircle2, Circle, Loader2, ArrowLeft, Sparkles, ClipboardList } from 'lucide-react';
import { generatePackingAssistant } from '../services/geminiService';
import { UserProfile } from '../types';

interface PackingScoutProps {
  destination: string;
  duration: number;
  user: UserProfile;
  onBack: () => void;
}

const PackingScout: React.FC<PackingScoutProps> = ({ destination, duration, user, onBack }) => {
  const [loading, setLoading] = useState(false);
  const [checklist, setChecklist] = useState<any[]>([]);
  const [checkedItems, setCheckedItems] = useState<Set<string>>(new Set());

  useEffect(() => {
    const fetchChecklist = async () => {
      setLoading(true);
      try {
        const data = await generatePackingAssistant(destination, duration, user.preferences.travelStyle);
        setChecklist(data);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetchChecklist();
  }, [destination, duration, user.preferences.travelStyle]);

  const toggleItem = (item: string) => {
    const next = new Set(checkedItems);
    if (next.has(item)) next.delete(item);
    else next.add(item);
    setCheckedItems(next);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 md:space-y-12 animate-fade-in pb-20 px-4">
      <div className="flex items-center justify-between">
        <button onClick={onBack} className="flex items-center gap-3 text-slate-500 hover:text-emerald-600 transition-colors font-black uppercase tracking-widest text-[10px]">
            <ArrowLeft className="w-5 h-5" /> Back
        </button>
        <span className="bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-widest border border-emerald-100 dark:border-emerald-500/20">
            Inventory Simulation Active
        </span>
      </div>
      <div className="glass-morphism rounded-[2.5rem] p-8 md:p-12 border border-emerald-100 dark:border-white/5 bg-white dark:bg-slate-900/40 relative overflow-hidden shadow-premium">
        <div className="flex flex-col md:flex-row items-center gap-8 md:gap-10 mb-12 md:mb-16 text-center md:text-left">
            <div className="w-20 h-20 sm:w-24 sm:h-24 bg-emerald-600 rounded-[2rem] flex items-center justify-center shadow-lg shrink-0">
                <ShoppingBag className="w-10 h-10 sm:w-12 sm:h-12 text-white" />
            </div>
            <div>
                <h1 className="text-3xl md:text-4xl font-black text-slate-900 dark:text-white tracking-tighter leading-none mb-3">Packing Scout: {destination}</h1>
                <p className="text-slate-600 dark:text-slate-400 font-medium text-base sm:text-lg leading-relaxed max-w-lg">
                    Intelligent inventory optimization for your {duration}-day cycle.
                </p>
            </div>
        </div>
        {loading ? (
            <div className="py-20 flex flex-col items-center gap-6">
                <Loader2 className="w-12 h-12 text-emerald-600 animate-spin" />
                <p className="text-slate-500 font-black text-[10px] uppercase tracking-widest animate-pulse">Simulating Gear Delta...</p>
            </div>
        ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-10">
                {checklist.map((cat, i) => (
                    <div key={i} className="space-y-6">
                        <h3 className="text-[10px] font-black text-emerald-600 dark:text-emerald-400 uppercase tracking-widest flex items-center gap-2">
                            <Sparkles className="w-4 h-4" /> {cat.category}
                        </h3>
                        <div className="space-y-3">
                            {cat.items.map((item: any, j: number) => {
                                const isChecked = checkedItems.has(item.item);
                                return (
                                    <button 
                                        key={j} 
                                        onClick={() => toggleItem(item.item)}
                                        className={`w-full text-left p-5 rounded-2xl border transition-all flex items-start gap-4 shadow-sm ${isChecked ? 'bg-emerald-50 dark:bg-emerald-900/10 border-emerald-100' : 'bg-white dark:bg-slate-950/40 border-slate-100 hover:border-emerald-200'}`}
                                    >
                                        <div className="mt-1 shrink-0">
                                            {isChecked ? <CheckCircle2 className="w-5 h-5 text-emerald-600" /> : <Circle className="w-5 h-5 text-slate-200" />}
                                        </div>
                                        <div className="min-w-0">
                                            <p className={`font-black text-sm transition-all ${isChecked ? 'text-slate-400 line-through' : 'text-slate-900 dark:text-white'}`}>{item.item}</p>
                                            <p className="text-[11px] text-slate-500 font-bold mt-1 leading-relaxed opacity-60 line-clamp-1">{item.reason}</p>
                                        </div>
                                    </button>
                                );
                            })}
                        </div>
                    </div>
                ))}
            </div>
        )}
        {!loading && checklist.length > 0 && (
            <div className="mt-16 pt-10 border-t border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-8">
                <div className="flex items-center gap-4">
                    <div className="p-3 bg-emerald-50 dark:bg-emerald-900/30 rounded-xl border border-emerald-100">
                        <ClipboardList className="w-6 h-6 text-emerald-600" />
                    </div>
                    <div>
                        <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest">Inventory Delta</p>
                        <p className="text-slate-900 dark:text-white font-black text-base">{checkedItems.size} / {checklist.reduce((acc, c) => acc + c.items.length, 0)} READY</p>
                    </div>
                </div>
                <button className="w-full sm:w-auto px-10 py-4 bg-emerald-600 text-white rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-emerald-700 transition-all shadow-xl">
                    EXPORT MANIFEST
                </button>
            </div>
        )}
      </div>
    </div>
  );
};

export default PackingScout;
