
import React, { useState, useEffect } from 'react';
import { Users, DollarSign, Activity, Map, MessageSquare, Clock, ArrowUpRight, ArrowDownRight, IndianRupee, Sparkles, Globe, TrendingUp } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const CompanyDashboard: React.FC = () => {
    const [revenue, setRevenue] = useState(104202000);
    const [activeUsers, setActiveUsers] = useState(12405);
    const [growth, setGrowth] = useState(12.4);
    const [chartData, setChartData] = useState([
        { name: '00:00', revenue: 350000, users: 240 },
        { name: '04:00', revenue: 280000, users: 139 },
        { name: '08:00', revenue: 160000, users: 980 },
        { name: '12:00', revenue: 240000, users: 390 },
        { name: '16:00', revenue: 150000, users: 480 },
        { name: '20:00', revenue: 190000, users: 380 },
        { name: '24:00', revenue: 300000, users: 430 },
    ]);
    const [currentTime, setCurrentTime] = useState(new Date());

    useEffect(() => {
        const interval = setInterval(() => {
            setCurrentTime(new Date());
            setRevenue(prev => prev + Math.floor(Math.random() * 40000) - 8000);
            setActiveUsers(prev => prev + Math.floor(Math.random() * 10) - 4);
        }, 3000);
        return () => clearInterval(interval);
    }, []);

    const trendingDestinations = [
        { name: 'Bali, Indonesia', growth: '+24%', users: '2.4k', status: 'POPULAR' },
        { name: 'Lisbon, Portugal', growth: '+18%', users: '1.9k', status: 'TRENDING' },
        { name: 'Mumbai, India', growth: '+32%', users: '4.1k', status: 'STABLE' },
        { name: 'Mexico City, MX', growth: '+12%', users: '1.2k', status: 'STABLE' },
    ];

    const formatCurrency = (val: number) => {
        return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(val);
    };

    return (
        <div className="space-y-10 animate-fade-in pb-12">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div>
                    <h1 className="text-4xl font-black text-slate-900 dark:text-white tracking-tight">Admin Insights</h1>
                    <p className="text-slate-500 font-medium text-sm mt-1">Platform performance overview</p>
                </div>
                <div className="flex gap-4">
                    <div className="flex items-center text-[10px] text-indigo-600 dark:text-amber-500 font-bold bg-white dark:bg-white/5 border border-black/5 dark:border-white/5 px-5 py-2.5 rounded-xl tracking-widest shadow-sm uppercase">
                        <Clock className="w-4 h-4 mr-2" />
                        {currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {[
                    { label: 'Total Travelers', val: activeUsers.toLocaleString(), icon: Users, color: 'text-indigo-600' },
                    { label: 'Gross Bookings', val: formatCurrency(revenue), icon: IndianRupee, color: 'text-emerald-500' },
                    { label: 'Growth Rate', val: `${growth}%`, icon: TrendingUp, color: 'text-amber-500' },
                    { label: 'Platform Load', val: 'Minimal', icon: Activity, color: 'text-indigo-400' }
                ].map((stat, i) => (
                    <div key={i} className="glass-morphism p-6 rounded-[2rem] shadow-md transition-all hover:shadow-xl">
                        <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-6 bg-black/5 dark:bg-white/5 ${stat.color}`}>
                            <stat.icon className="w-6 h-6" />
                        </div>
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">{stat.label}</p>
                        <h3 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">{stat.val}</h3>
                    </div>
                ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
                <div className="lg:col-span-4 glass-morphism rounded-[2rem] shadow-md overflow-hidden flex flex-col h-[450px]">
                    <div className="p-6 border-b border-black/5 dark:border-white/5 flex justify-between items-center">
                        <h3 className="font-bold text-slate-900 dark:text-white text-sm uppercase tracking-widest flex items-center gap-3">
                            <Globe className="w-4 h-4 text-indigo-600" />
                            Popular Hubs
                        </h3>
                    </div>
                    <div className="flex-1 overflow-y-auto scrollbar-hide">
                        {trendingDestinations.map((dest, idx) => (
                            <div key={idx} className="p-6 border-b border-black/5 dark:border-white/5 hover:bg-black/5 dark:hover:bg-white/[0.02] transition-colors cursor-pointer">
                                <div className="flex justify-between items-start mb-2">
                                    <h4 className="font-bold text-slate-900 dark:text-white">{dest.name}</h4>
                                    <span className={`text-[8px] font-black px-2 py-1 rounded-md uppercase tracking-widest ${dest.status === 'POPULAR' ? 'bg-indigo-600 text-white' : 'bg-black/5 dark:bg-white/10 text-slate-500'}`}>
                                        {dest.status}
                                    </span>
                                </div>
                                <div className="flex items-center text-[10px] font-bold text-slate-400 uppercase tracking-widest gap-4">
                                    <span className="flex items-center gap-1.5 text-emerald-500"><TrendingUp className="w-3 h-3" /> {dest.growth}</span>
                                    <span className="flex items-center gap-1.5">{dest.users} travelers</span>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                <div className="lg:col-span-8 glass-morphism rounded-[2rem] shadow-md p-8 flex flex-col h-[450px]">
                    <h3 className="font-bold text-slate-900 dark:text-white text-sm uppercase tracking-widest mb-10">Revenue Trends</h3>
                    <div className="flex-1 w-full h-full">
                        <ResponsiveContainer width="100%" height="100%">
                            <AreaChart data={chartData}>
                                <defs>
                                    <linearGradient id="colorRv" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.2}/>
                                        <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                                    </linearGradient>
                                </defs>
                                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10, fontWeight: 700}} dy={15} />
                                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 10, fontWeight: 700}} />
                                <Tooltip 
                                    contentStyle={{backgroundColor: '#ffffff', border: '1px solid #e2e8f0', borderRadius: '12px', padding: '12px'}} 
                                    itemStyle={{color: '#4f46e5', fontWeight: 700, fontSize: '12px'}}
                                    labelStyle={{color: '#64748b', fontWeight: 700, fontSize: '10px', marginBottom: '4px', textTransform: 'uppercase'}}
                                />
                                <CartesianGrid vertical={false} stroke="rgba(0,0,0,0.02)" />
                                <Area 
                                    type="monotone" 
                                    dataKey="revenue" 
                                    stroke="#4f46e5" 
                                    strokeWidth={3} 
                                    fillOpacity={1} 
                                    fill="url(#colorRv)" 
                                />
                            </AreaChart>
                        </ResponsiveContainer>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default CompanyDashboard;
