
import React from 'react';
import { UserProfile, ConciergePersona } from '../types';
import { Crown, Bot, MapPin, Heart, Zap, Globe, Star, Compass } from 'lucide-react';

interface ProfileProps {
    user: UserProfile;
    onUpdate: (data: Partial<UserProfile>) => void;
}

const Profile: React.FC<ProfileProps> = ({ user, onUpdate }) => {
    const nextTier = user.loyaltyPoints > 10000 ? 25000 : 10000;
    const progress = (user.loyaltyPoints / nextTier) * 100;

    const personas: {id: ConciergePersona, label: string, desc: string, icon: any, color: string}[] = [
        { id: 'professional', label: 'Professional', desc: 'Formal and direct guidance.', icon: Crown, color: 'text-indigo-400' },
        { id: 'friendly', label: 'Friendly', desc: 'Like a local expert friend.', icon: Heart, color: 'text-emerald-400' },
        { id: 'scout', label: 'Scout', desc: 'Adventurous and bold advice.', icon: Compass, color: 'text-amber-400' }
    ];

    return (
        <div className="max-w-4xl mx-auto space-y-12 animate-fade-in pb-20">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-4xl font-black text-slate-900 dark:text-white tracking-tighter">My Account</h1>
                    <p className="text-slate-500 dark:text-slate-400 text-sm font-bold uppercase tracking-widest mt-1">Profile Synchronized</p>
                </div>
            </div>
            
            <div className="glass-morphism squircle p-12 border border-black/5 dark:border-white/5 shadow-xl flex flex-col md:flex-row items-center gap-12 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-600/5 dark:bg-amber-500/5 rounded-full blur-[100px] -mr-32 -mt-32"></div>
                
                <div className="w-48 h-48 rounded-full ring-[16px] ring-black/5 dark:ring-white/5 shadow-2xl overflow-hidden shrink-0 relative group">
                     <img src={`https://api.dicebear.com/9.x/avataaars/svg?seed=${user.name}`} className="w-full h-full bg-white dark:bg-slate-900" />
                     <div className="absolute bottom-4 right-4 w-10 h-10 bg-indigo-600 dark:bg-amber-500 rounded-2xl flex items-center justify-center shadow-lg border-2 border-white dark:border-slate-950">
                         <Star className="w-5 h-5 text-white dark:text-slate-950 fill-current" />
                     </div>
                </div>

                <div className="flex-1 text-center md:text-left relative z-10">
                    <div className="flex items-center justify-center md:justify-start gap-5 mb-4">
                        <h2 className="text-5xl font-black text-slate-900 dark:text-white tracking-tighter leading-none">{user.name}</h2>
                        <span className="bg-indigo-600/10 dark:bg-amber-500/10 text-indigo-600 dark:text-amber-500 px-4 py-1.5 rounded-xl text-[9px] font-black uppercase tracking-widest border border-black/5 dark:border-white/5">Verified Explorer</span>
                    </div>
                    <p className="text-slate-500 dark:text-slate-400 font-medium text-xl mb-10">{user.email}</p>
                    <div className="flex flex-wrap justify-center md:justify-start gap-4">
                        <div className="px-6 py-2.5 bg-black/5 dark:bg-white/5 text-indigo-600 dark:text-indigo-400 rounded-2xl text-[10px] font-black uppercase tracking-widest border border-black/5 dark:border-white/5 flex items-center gap-3">
                            <Zap className="w-4 h-4" /> {user.type.toUpperCase()}
                        </div>
                        <div className="px-6 py-2.5 bg-black/5 dark:bg-white/5 text-amber-600 dark:text-amber-400 rounded-2xl text-[10px] font-black uppercase tracking-widest border border-black/5 dark:border-white/5 flex items-center gap-3">
                            <Globe className="w-4 h-4" /> GLOBAL TRAVELER
                        </div>
                    </div>
                </div>
            </div>

            <div className="grid md:grid-cols-12 gap-10">
                <div className="md:col-span-7 glass-morphism p-12 squircle border border-black/5 dark:border-white/5 shadow-xl">
                    <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-10 flex items-center gap-4">
                        <Bot className="w-8 h-8 text-indigo-600 dark:text-amber-500" /> Assistant Voice
                    </h3>
                    <div className="space-y-5">
                        {personas.map(p => (
                            <button 
                                key={p.id} 
                                onClick={() => onUpdate({ persona: p.id })} 
                                className={`w-full p-8 rounded-[2rem] border-2 transition-all duration-500 text-left flex items-center gap-6 ${user.persona === p.id ? 'border-indigo-600 dark:border-amber-500 bg-indigo-600/5 dark:bg-amber-500/5 shadow-md' : 'border-black/5 dark:border-white/5 bg-black/[0.02] dark:bg-white/[0.02] hover:bg-black/5 dark:hover:bg-white/5'}`}
                            >
                                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center transition-all ${user.persona === p.id ? 'bg-indigo-600 dark:bg-amber-500 text-white dark:text-slate-950' : 'bg-white dark:bg-slate-950 text-slate-400 dark:text-slate-600 border border-black/5 dark:border-white/5'}`}>
                                    <p.icon className="w-8 h-8" />
                                </div>
                                <div className="flex-1">
                                    <p className={`font-black text-xl leading-none mb-1 ${user.persona === p.id ? 'text-slate-900 dark:text-white' : 'text-slate-500 dark:text-slate-600'}`}>{p.label}</p>
                                    <p className="text-sm font-medium text-slate-500">{p.desc}</p>
                                </div>
                                {user.persona === p.id && <div className="w-3 h-3 rounded-full bg-indigo-600 dark:bg-amber-500 animate-pulse" />}
                            </button>
                        ))}
                    </div>
                </div>

                <div className="md:col-span-5 space-y-10">
                    <div className="bg-white dark:bg-slate-950 p-12 squircle border border-black/5 dark:border-white/5 shadow-xl flex flex-col justify-between h-full min-h-[400px]">
                        <div>
                            <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-6">Loyalty Progress</p>
                            <h3 className="text-6xl font-black text-slate-900 dark:text-white mb-2 leading-none">{user.loyaltyPoints.toLocaleString()} <span className="text-lg text-slate-400 font-bold tracking-normal">pts</span></h3>
                            
                            <div className="mt-16 space-y-8">
                                <div className="flex justify-between text-[10px] font-black text-slate-500 uppercase tracking-widest">
                                    <span>Traveler</span>
                                    <span>Gold Tier</span>
                                </div>
                                <div className="w-full h-5 bg-black/5 dark:bg-white/5 rounded-full overflow-hidden p-1.5">
                                    <div 
                                        className="h-full bg-indigo-600 dark:bg-amber-500 rounded-full transition-all duration-[2s] ease-out shadow-sm" 
                                        style={{ width: `${progress}%` }} 
                                    />
                                </div>
                                <div className="flex items-center gap-3 text-[10px] text-indigo-600 dark:text-amber-500/60 font-black uppercase tracking-widest">
                                    <Star className="w-3.5 h-3.5 fill-current" /> {nextTier - user.loyaltyPoints} points to your next reward.
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Profile;
