
import React, { useState } from 'react';
import { UserRole, UserType, UserProfile } from '../types';
import { Plane, Lock, Mail, ArrowRight, User, Activity, Sparkles, ShieldCheck, Loader2 } from 'lucide-react';
import ThemeToggle from './ThemeToggle';

interface LoginProps {
  onLogin: (role: UserRole) => void;
  onSignup: (data: Partial<UserProfile>) => void;
  isDarkMode: boolean;
  onToggleTheme: () => void;
}

const Login: React.FC<LoginProps> = ({ onLogin, onSignup, isDarkMode, onToggleTheme }) => {
  const [isSignup, setIsSignup] = useState(false);
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      if (isSignup) onSignup({ name, email, type: UserType.NOMAD });
      else onLogin(UserRole.TRAVELER);
      setLoading(false);
    }, 1200);
  };

  return (
    <div className="min-h-screen flex bg-white dark:bg-slate-950 transition-colors duration-500 selection:bg-indigo-500 selection:text-white relative">
      <div className="absolute top-8 right-8 z-[100]">
        <ThemeToggle isDarkMode={isDarkMode} onToggle={onToggleTheme} />
      </div>

      <div className="hidden lg:flex lg:w-[55%] bg-slate-50 dark:bg-brand-950 items-center justify-center p-20 relative overflow-hidden border-r border-indigo-100 dark:border-white/5 transition-colors">
        <div className="aura-layer">
          <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-indigo-600/10 rounded-full -mr-96 -mt-96 blur-[160px] animate-aura-drift"></div>
          <div className="absolute bottom-0 left-0 w-[600px] h-[600px] bg-amber-500/5 rounded-full -ml-96 -mb-96 blur-[140px] animate-aura-drift" style={{ animationDirection: 'reverse' }}></div>
        </div>
        
        <div className="relative z-10 max-w-xl">
            <div className="flex items-center gap-4 mb-16">
                <div className="w-12 h-12 bg-indigo-600 rounded-xl flex items-center justify-center shadow-ontrack group hover:bg-amber-500 transition-all duration-700">
                    <Activity className="w-6 h-6 text-white" />
                </div>
                <span className="text-3xl font-bold font-display text-slate-900 dark:text-white tracking-tighter leading-none">On<span className="text-indigo-600 dark:text-amber-500">Track</span></span>
            </div>
            <h1 className="text-6xl font-extrabold font-display text-slate-900 dark:text-white mb-8 leading-[1.1] tracking-tight">
                Travel with <br /><span className="text-indigo-600 dark:text-amber-500">Intelligent Clarity.</span>
            </h1>
            <p className="text-slate-500 dark:text-slate-400 text-xl font-medium leading-relaxed mb-12">
                The world's most sophisticated concierge ecosystem. Tailored planning for professional explorers.
            </p>
            <div className="flex items-center gap-6">
                <div className="flex -space-x-3">
                    {[1,2,3,4].map(i => (
                        <div key={i} className="w-10 h-10 rounded-full border-2 border-white dark:border-slate-950 bg-slate-200 dark:bg-slate-800 flex items-center justify-center overflow-hidden">
                            <img src={`https://api.dicebear.com/9.x/avataaars/svg?seed=${i * 12}`} className="w-full h-full" />
                        </div>
                    ))}
                </div>
                <p className="text-[12px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest">Trusted by 12,000+ Nomads</p>
            </div>
        </div>
      </div>

      <div className="w-full lg:w-[45%] flex items-center justify-center p-8 md:p-20 relative bg-white dark:bg-slate-950 transition-colors">
        <div className="max-w-md w-full space-y-10">
            <div>
                <h2 className="text-3xl font-bold font-display text-slate-900 dark:text-white tracking-tight mb-3">
                    {isSignup ? 'Create Account' : 'Welcome Back'}
                </h2>
                <p className="text-slate-500 dark:text-slate-400 text-[16px] font-medium leading-relaxed">Please authenticate your credentials to access the concierge.</p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-6">
                {isSignup && (
                    <div className="space-y-2">
                        <label className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest ml-1">Full Name</label>
                        <input type="text" placeholder="e.g. Alex Wanderer" value={name} onChange={e => setName(e.target.value)} className="w-full px-6 py-4 bg-slate-50 dark:bg-white/5 border border-indigo-100 dark:border-white/5 rounded-xl outline-none focus:border-indigo-600/50 dark:focus:border-amber-500/50 text-slate-900 dark:text-white font-medium transition-all shadow-inner" required />
                    </div>
                )}
                <div className="space-y-2">
                    <label className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest ml-1">Work Email</label>
                    <input type="email" placeholder="nomad@ontrack.ai" value={email} onChange={e => setEmail(e.target.value)} className="w-full px-6 py-4 bg-slate-50 dark:bg-white/5 border border-indigo-100 dark:border-white/5 rounded-xl outline-none focus:border-indigo-600/50 dark:focus:border-amber-500/50 text-slate-900 dark:text-white font-medium transition-all shadow-inner" required />
                </div>
                <div className="space-y-2">
                    <label className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-widest ml-1">Secure Passcode</label>
                    <input type="password" placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)} className="w-full px-6 py-4 bg-slate-50 dark:bg-white/5 border border-indigo-100 dark:border-white/5 rounded-xl outline-none focus:border-indigo-600/50 dark:focus:border-amber-500/50 text-slate-900 dark:text-white font-medium transition-all shadow-inner" required />
                </div>

                <button type="submit" disabled={loading} className="w-full bg-indigo-600 dark:bg-white hover:bg-indigo-700 dark:hover:bg-slate-100 text-white dark:text-slate-950 font-bold py-5 rounded-xl shadow-ontrack transition-all duration-300 active:scale-95 flex items-center justify-center gap-3 mt-10 text-[15px] group">
                    {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : (isSignup ? 'Initialize Uplink' : 'Authenticate Access')}
                    <ArrowRight className="w-5 h-5 group-hover:translate-x-1.5 transition-transform" />
                </button>
            </form>

            <div className="flex flex-col gap-6 text-center">
                <button onClick={() => setIsSignup(!isSignup)} className="text-[11px] font-bold text-slate-500 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-white transition-all uppercase tracking-widest">
                    {isSignup ? 'Already have an ID? Sign in' : "Request a new nomadic ID"}
                </button>
                <div className="pt-8 flex items-center justify-center gap-6 opacity-30 grayscale dark:invert">
                    <ShieldCheck className="w-7 h-7 text-slate-900" />
                    <Sparkles className="w-7 h-7 text-slate-900" />
                    <Lock className="w-7 h-7 text-slate-900" />
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
