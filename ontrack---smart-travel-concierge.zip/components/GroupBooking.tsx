
import React from 'react';
import { Users, Sparkles, MessageSquare, CreditCard, Vote, Zap, ShieldCheck, Globe } from 'lucide-react';
import { getReliableImageUrl } from '../services/geminiService';

const GroupBooking: React.FC = () => {
    const placeholderImg = getReliableImageUrl('bali', 'hero');

    const features = [
        {
            title: "Shared Canvas Itinerary",
            desc: "Drag, drop, and edit travel plans in real-time with your entire group. Everyone sees the latest version instantly.",
            icon: Sparkles,
            color: "text-indigo-600"
        },
        {
            title: "Democratic Voting",
            desc: "Can't decide on dinner? Host quick polls for restaurants, activities, or flights within your group chat.",
            icon: Vote,
            color: "text-amber-500"
        },
        {
            title: "Neural Split-Payments",
            desc: "Automated expense tracking and splitting. Settle up seamlessly with one click using our integrated secure ledger.",
            icon: CreditCard,
            color: "text-emerald-500"
        },
        {
            title: "Live Presence Sync",
            desc: "See who's online and viewing the plan. High-precision coordination for seamless arrivals and departures.",
            icon: Globe,
            color: "text-blue-500"
        }
    ];

    return (
        <div className="space-y-16 animate-fade-in pb-20">
            <div className="relative h-[400px] rounded-[3rem] overflow-hidden flex flex-col items-center justify-center text-center p-10 group">
                <div 
                    className="absolute inset-0 z-0 bg-cover bg-center scale-105 group-hover:scale-100 transition-transform duration-[5s]" 
                    style={{ backgroundImage: `url(${placeholderImg})` }}
                />
                <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-[2px] z-10" />
                
                <div className="relative z-20 space-y-6 max-w-2xl">
                    <span className="bg-amber-500 text-slate-950 px-6 py-2 rounded-full text-[10px] font-black uppercase tracking-[0.2em] shadow-yellow-pulse animate-bounce">
                        Coming Soon
                    </span>
                    <h1 className="text-5xl md:text-7xl font-black text-white tracking-tighter leading-none font-display">
                        Collaborative <span className="text-gradient-gold">Nomadism</span>
                    </h1>
                    <p className="text-slate-200 text-lg md:text-xl font-medium leading-relaxed opacity-90">
                        Stop planning in silos. Start exploring together with our next-generation group booking suite.
                    </p>
                    <div className="pt-6 flex flex-wrap justify-center gap-4">
                        <button className="px-8 py-4 bg-white text-slate-950 rounded-2xl font-black text-[12px] uppercase tracking-widest hover:bg-amber-500 transition-all shadow-xl">
                            Join Early Access Waitlist
                        </button>
                        <button className="px-8 py-4 glass-morphism text-white rounded-2xl font-black text-[12px] uppercase tracking-widest border border-white/20 hover:bg-white/10 transition-all">
                            View Beta Features
                        </button>
                    </div>
                </div>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
                {features.map((f, i) => (
                    <div key={i} className="glass-morphism p-10 rounded-[2.5rem] border border-slate-200/60 dark:border-white/5 hover:translate-y-[-8px] transition-all duration-500 group">
                        <div className={`w-14 h-14 rounded-2xl bg-black/5 dark:bg-white/5 flex items-center justify-center mb-8 group-hover:scale-110 transition-transform ${f.color}`}>
                            <f.icon className="w-7 h-7" />
                        </div>
                        <h3 className="text-xl font-black text-slate-900 dark:text-white mb-4 tracking-tight leading-tight">{f.title}</h3>
                        <p className="text-slate-500 dark:text-slate-400 text-sm font-medium leading-relaxed">{f.desc}</p>
                    </div>
                ))}
            </div>

            <div className="glass-morphism rounded-[3rem] p-12 border border-black/5 dark:border-white/5 flex flex-col md:flex-row items-center gap-12 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-600/5 dark:bg-amber-500/5 rounded-full blur-[100px] -mr-32 -mt-32"></div>
                
                <div className="flex-1 space-y-8 relative z-10">
                    <h2 className="text-3xl font-black text-slate-900 dark:text-white tracking-tighter">Why wait for the update?</h2>
                    <p className="text-slate-500 dark:text-slate-400 text-lg leading-relaxed font-medium">
                        Our group intelligence engine uses <span className="text-indigo-600 dark:text-amber-500 font-bold">Consensus Neural Logic</span> to resolve travel conflicts before they happen. We're currently fine-tuning the biometric payment gates for groups of 4 to 20 explorers.
                    </p>
                    <div className="flex items-center gap-4 text-xs font-black text-slate-400 uppercase tracking-widest">
                        <ShieldCheck className="w-5 h-5 text-emerald-500" /> Secure Multi-Account Sync
                    </div>
                </div>

                <div className="w-full md:w-80 space-y-4">
                    <div className="p-6 bg-white dark:bg-slate-900/50 rounded-3xl border border-black/5 dark:border-white/5 shadow-sm">
                        <div className="flex items-center gap-4 mb-4">
                            <div className="w-10 h-10 rounded-full bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center text-indigo-600">
                                <Users className="w-5 h-5" />
                            </div>
                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Active Beta Nodes</span>
                        </div>
                        <p className="text-2xl font-black text-slate-900 dark:text-white">1,402 Groups</p>
                    </div>
                    <div className="p-6 bg-white dark:bg-slate-900/50 rounded-3xl border border-black/5 dark:border-white/5 shadow-sm">
                         <div className="flex items-center gap-4 mb-4">
                            <div className="w-10 h-10 rounded-full bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center text-amber-600">
                                <Zap className="w-5 h-5" />
                            </div>
                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Neural Stability</span>
                        </div>
                        <p className="text-2xl font-black text-slate-900 dark:text-white">99.98% Ready</p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default GroupBooking;
