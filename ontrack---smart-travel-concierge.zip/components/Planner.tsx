
import React, { useState, useEffect } from 'react';
import { generateItinerary, generateTransportOptions, getLocationDescription } from '../services/geminiService';
import { ItineraryDay, TransportOption, ItineraryItem, UserProfile, Citation } from '../types';
import { Calendar, MapPin, Loader2, Plane, Clock, X, Utensils, Camera, Coffee, Info, Search, ArrowRightLeft, ShieldCheck, Crosshair, TrendingDown, Sparkles, Navigation } from 'lucide-react';
import DailyBriefing from './DailyBriefing';

interface PlannerProps {
    initialDestination?: string;
    initialOrigin?: string;
    user: UserProfile;
}

const Planner: React.FC<PlannerProps> = ({ initialDestination = '', initialOrigin = '', user }) => {
  const [destination, setDestination] = useState(initialDestination);
  const [origin, setOrigin] = useState(initialOrigin || 'Mumbai, IN');
  const [days, setDays] = useState(3);
  const [loading, setLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState('');
  const [itinerary, setItinerary] = useState<ItineraryDay[]>([]);
  const [transport, setTransport] = useState<TransportOption[]>([]);
  const [citations, setCitations] = useState<Citation[]>([]);
  const [showResults, setShowResults] = useState(false);
  const [isDetecting, setIsDetecting] = useState(false);

  const statusMessages = [
    "Analyzing flight patterns...",
    "Scanning weather systems...",
    "Curating hidden hotspots...",
    "Optimizing travel logistics...",
    "Validating secure nodes...",
    "Building your custom cycle..."
  ];

  useEffect(() => {
    if (initialDestination) handlePlanTrip();
  }, [initialDestination]);

  useEffect(() => {
    let msgIndex = 0;
    let interval: any;
    if (loading) {
        setLoadingStep(statusMessages[0]);
        interval = setInterval(() => {
            msgIndex = (msgIndex + 1) % statusMessages.length;
            setLoadingStep(statusMessages[msgIndex]);
        }, 2500);
    }
    return () => clearInterval(interval);
  }, [loading]);

  const handleDetectLocation = () => {
    if (!navigator.geolocation) return;
    setIsDetecting(true);
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const desc = await getLocationDescription(position.coords.latitude, position.coords.longitude);
        setOrigin(desc);
        setIsDetecting(false);
      },
      () => setIsDetecting(false)
    );
  };

  const handlePlanTrip = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!destination) return;
    setLoading(true);
    setShowResults(false);
    try {
      const transportTask = generateTransportOptions(origin, destination);
      const itineraryTask = generateItinerary(destination, days, user);
      const [tRes, iRes] = await Promise.all([transportTask, itineraryTask]);
      setTransport(tRes.options);
      setItinerary(iRes.itinerary);
      setCitations([...(iRes.citations || []), ...(tRes.citations || [])]);
      setShowResults(true);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const getActivityIcon = (type: string) => {
      switch(type.toLowerCase()) {
          case 'food': return <Utensils className="w-4 h-4 text-slate-950 dark:text-white" />;
          case 'sightseeing': return <Camera className="w-4 h-4 text-slate-950 dark:text-white" />;
          case 'transport': return <Plane className="w-4 h-4 text-slate-950 dark:text-white" />;
          case 'rest': return <Coffee className="w-4 h-4 text-slate-950 dark:text-white" />;
          default: return <Info className="w-4 h-4 text-slate-400" />;
      }
  };

  return (
    <div className="space-y-10 md:space-y-12 animate-fade-in pb-16 px-1 transition-colors">
      <div className="glass-morphism rounded-[2rem] sm:rounded-[2.5rem] p-6 sm:p-8 border border-slate-100 dark:border-white/5 relative z-40 shadow-xl bg-white dark:bg-slate-900/50">
         <form onSubmit={handlePlanTrip} className="flex flex-col lg:flex-row gap-4 sm:gap-5 items-stretch">
             <div className="flex-1 p-4 sm:p-5 bg-slate-50 dark:bg-white/5 border border-slate-100 dark:border-white/5 rounded-2xl flex flex-col justify-center">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Origin</label>
                <div className="flex items-center gap-3">
                    <input type="text" value={origin} onChange={(e) => setOrigin(e.target.value)} className="bg-transparent w-full outline-none text-slate-950 dark:text-white font-black text-base sm:text-lg" />
                    <button type="button" onClick={handleDetectLocation} className="p-2 text-slate-900 dark:text-white hover:bg-white dark:hover:bg-white/10 rounded-xl transition-all shadow-sm">{isDetecting ? <Loader2 className="w-5 h-5 animate-spin" /> : <Crosshair className="w-5 h-5" />}</button>
                </div>
             </div>
             <div className="flex-1 p-4 sm:p-5 bg-slate-50 dark:bg-white/5 border border-slate-100 dark:border-white/5 rounded-2xl flex flex-col justify-center">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Destination</label>
                <input type="text" value={destination} onChange={(e) => setDestination(e.target.value)} placeholder="Where to?" className="bg-transparent w-full outline-none text-slate-950 dark:text-white font-black text-base sm:text-lg" required />
             </div>
             <div className="w-full lg:w-32 p-4 sm:p-5 bg-slate-50 dark:bg-white/5 border border-slate-100 dark:border-white/5 rounded-2xl flex flex-col justify-center">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Days</label>
                <div className="flex items-center gap-2">
                    <input type="number" min="1" max="14" value={days} onChange={(e) => setDays(parseInt(e.target.value))} className="bg-transparent w-10 outline-none text-slate-950 dark:text-white font-black text-base sm:text-lg" />
                    <span className="text-[11px] font-black text-slate-400 uppercase tracking-tight">Days</span>
                </div>
             </div>
             <button type="submit" disabled={loading} className="lg:w-40 bg-slate-900 dark:bg-white text-white dark:text-slate-950 font-black py-5 lg:py-0 rounded-2xl shadow-xl transition-all hover:bg-slate-800 dark:hover:bg-slate-100 flex items-center justify-center gap-3">
                {loading ? <Loader2 className="animate-spin w-6 h-6" /> : <Search className="w-6 h-6" />}
                <span className="lg:hidden">{loading ? 'Processing...' : 'Plan Journey'}</span>
             </button>
         </form>
      </div>

      {loading && (
          <div className="py-20 md:py-24 flex flex-col items-center text-center animate-fade-in">
              <div className="w-16 h-16 sm:w-20 sm:h-20 bg-slate-50 dark:bg-white/5 rounded-[2rem] flex items-center justify-center mb-8 sm:mb-10 relative">
                <div className="absolute inset-0 border-4 border-slate-900/10 dark:border-white/10 rounded-[2rem] animate-ping"></div>
                <Loader2 className="w-8 h-8 sm:w-10 sm:h-10 text-slate-900 dark:text-white animate-spin" />
              </div>
              <h3 className="text-xl sm:text-2xl font-black font-display text-slate-950 dark:text-white mb-4 uppercase tracking-tighter">{loadingStep}</h3>
              <p className="text-slate-500 dark:text-slate-400 font-bold text-sm sm:text-lg max-w-md px-4">Orchestrating an optimized itinerary cycle for your biometric profile.</p>
          </div>
      )}

      {showResults && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 md:gap-12">
            <div className="lg:col-span-4 space-y-8">
                <div className="lg:sticky lg:top-24 space-y-6 md:space-y-8">
                    <DailyBriefing dayText={`Your strategic ${days}-day plan for ${destination} is complete. Optimization: Explorer Tier.`} user={user} />
                    
                    <div className="glass-morphism rounded-[2rem] p-6 sm:p-8 border border-slate-100 dark:border-white/5 bg-white dark:bg-slate-900/50 shadow-lg">
                        <div className="flex items-center justify-between mb-6">
                            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Telemetry Exchange</h4>
                            <span className="bg-slate-900/5 dark:bg-white/5 text-slate-900 dark:text-white px-2 py-1 rounded text-[9px] font-black uppercase tracking-widest">REAL-TIME</span>
                        </div>
                        <div className="flex items-center justify-between">
                            <div className="text-center">
                                <p className="text-[9px] font-black text-slate-400 mb-1 uppercase">Origin Hub</p>
                                <span className="text-lg font-black text-slate-950 dark:text-white">1 INR</span>
                            </div>
                            <ArrowRightLeft className="w-5 h-5 text-slate-300" />
                            <div className="text-center">
                                <p className="text-[9px] font-black text-slate-400 mb-1 uppercase">Arrival Node</p>
                                <span className="text-lg font-black text-slate-900 dark:text-white">~ 0.04 AED</span>
                            </div>
                        </div>
                    </div>

                    <div className="glass-morphism rounded-[2rem] p-6 sm:p-8 border border-slate-100 dark:border-white/5 bg-white dark:bg-slate-900/50 shadow-lg">
                        <h3 className="font-black text-slate-950 dark:text-white text-sm mb-6 flex items-center gap-3">
                            <ShieldCheck className="w-4 h-4 text-slate-400" /> 
                            Secure Citations
                        </h3>
                        <div className="space-y-3">
                            {citations.slice(0, 3).map((c, i) => (
                                <a key={i} href={c.uri} target="_blank" rel="noopener noreferrer" className="block p-4 bg-slate-50 dark:bg-white/5 rounded-xl border border-transparent hover:border-slate-300 transition-all shadow-sm">
                                    <p className="text-[13px] font-black text-slate-800 dark:text-slate-300 line-clamp-1">{c.title}</p>
                                    <div className="flex items-center mt-1 text-[9px] text-slate-400 font-bold uppercase tracking-widest">{new URL(c.uri).hostname}</div>
                                </a>
                            ))}
                        </div>
                    </div>
                </div>
            </div>

            <div className="lg:col-span-8 space-y-8 md:space-y-12">
                <section className="glass-morphism rounded-[2rem] md:rounded-[3rem] p-6 sm:p-10 md:p-14 border border-slate-100 dark:border-white/5 bg-white dark:bg-slate-900/50 shadow-2xl">
                     <h2 className="text-2xl sm:text-3xl font-black font-display text-slate-950 dark:text-white mb-10 md:mb-14 flex items-center gap-4">
                        <Calendar className="w-6 h-6 sm:w-8 sm:h-8 text-slate-900 dark:text-white" /> 
                        Optimal Cycles
                     </h2>
                     <div className="space-y-12 md:space-y-14 border-l-2 border-slate-100 dark:border-white/10 ml-2 sm:ml-4">
                         {itinerary.map((day) => (
                             <div key={day.day} className="pl-8 sm:pl-12 relative">
                                 <div className="absolute -left-[7px] sm:-left-[9px] top-0 w-3 h-3 sm:w-4 sm:h-4 rounded-full bg-slate-900 dark:bg-white ring-4 ring-white dark:ring-slate-950 shadow-sm" />
                                 <div className="flex flex-col sm:flex-row justify-between mb-6 sm:mb-8 gap-4 sm:gap-5">
                                     <div>
                                        <h3 className="text-xl sm:text-2xl font-black font-display text-slate-950 dark:text-white tracking-tighter uppercase">Cycle {day.day}</h3>
                                        <p className="text-slate-400 text-[10px] font-black uppercase tracking-[0.2em] mt-1 flex items-center gap-2">
                                            <Sparkles className="w-3 h-3" /> {day.weatherForecast}
                                        </p>
                                     </div>
                                     <span className="px-3 py-1.5 bg-slate-50 dark:bg-white/5 text-slate-500 text-[9px] font-black uppercase tracking-widest rounded-lg self-start border border-slate-100 dark:border-transparent">
                                        Density: {day.crowdLevel}
                                     </span>
                                 </div>
                                 <div className="grid gap-3 sm:gap-4">
                                     {day.items.map((item, i) => (
                                         <div key={i} className="flex items-center p-4 sm:p-5 bg-white dark:bg-slate-950/40 rounded-xl sm:rounded-2xl border border-slate-100 dark:border-white/5 hover:border-slate-300 transition-all group shadow-sm">
                                             <div className="w-16 sm:w-20 text-[9px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest">{item.time}</div>
                                             <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl bg-slate-950 dark:bg-white flex items-center justify-center mx-3 sm:mx-5 group-hover:scale-105 transition-transform shadow-lg">
                                                {getActivityIcon(item.type)}
                                             </div>
                                             <div className="flex-1 min-w-0">
                                                 <p className="font-black text-slate-950 dark:text-white text-sm sm:text-[16px] leading-tight truncate group-hover:text-slate-600 transition-colors uppercase tracking-tight">{item.activity}</p>
                                                 <p className="text-[9px] sm:text-[10px] font-bold text-slate-400 mt-1 truncate uppercase tracking-widest flex items-center gap-1.5">
                                                    <MapPin className="w-2.5 h-2.5" /> {item.location}
                                                 </p>
                                             </div>
                                         </div>
                                     ))}
                                 </div>
                             </div>
                         ))}
                     </div>
                </section>
            </div>
        </div>
      )}
    </div>
  );
};

export default Planner;
