
import React, { useState, useEffect } from 'react';
import { ShieldAlert, MapPin, Phone, Loader2, ArrowLeft, Activity, Info } from 'lucide-react';
import { getSafetyIntelligence } from '../services/geminiService';

interface SafetyRadarProps {
  location: string;
  onBack: () => void;
}

const SafetyRadar: React.FC<SafetyRadarProps> = ({ location, onBack }) => {
  const [loading, setLoading] = useState(false);
  const [intel, setIntel] = useState<{ text: string, citations: any[] } | null>(null);

  useEffect(() => {
    const fetchSafety = async () => {
      setLoading(true);
      try {
        const data = await getSafetyIntelligence(location);
        setIntel(data);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    fetchSafety();
  }, [location]);

  return (
    <div className="max-w-4xl mx-auto space-y-8 md:space-y-12 animate-fade-in pb-20 px-4">
      <div className="flex items-center justify-between">
        <button onClick={onBack} className="flex items-center gap-3 text-slate-500 hover:text-rose-600 transition-colors font-black uppercase tracking-widest text-[10px]">
            <ArrowLeft className="w-5 h-5" /> Back
        </button>
        <span className="bg-rose-50 dark:bg-rose-500/10 text-rose-600 dark:text-rose-400 px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-widest border border-rose-100 dark:border-rose-500/20">
            Tactical Safety Grid
        </span>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 md:gap-8">
        <div className="lg:col-span-8 space-y-6">
          <div className="glass-morphism rounded-[2.5rem] p-8 md:p-10 border border-rose-100 dark:border-white/5 bg-white dark:bg-slate-900/40 relative overflow-hidden shadow-xl">
             <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6 mb-8 text-center sm:text-left">
                <div className="w-16 h-16 bg-rose-600 rounded-2xl flex items-center justify-center shadow-xl shrink-0">
                    <ShieldAlert className="w-8 h-8 text-white" />
                </div>
                <div>
                    <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tighter mb-2">Safety Radar: {location}</h1>
                    <p className="text-[10px] text-slate-500 font-black uppercase tracking-widest">Global Rescue Intelligence Active</p>
                </div>
             </div>
             {loading ? (
                 <div className="py-20 flex flex-col items-center gap-6">
                    <Loader2 className="w-12 h-12 text-rose-600 animate-spin" />
                    <p className="text-slate-500 font-black text-[10px] uppercase tracking-widest animate-pulse">Scanning Grids...</p>
                 </div>
             ) : (
                <div className="space-y-6">
                    <div className="p-6 bg-rose-50/30 dark:bg-slate-950/50 rounded-2xl border border-rose-100 dark:border-white/5 shadow-inner">
                        <p className="text-slate-700 dark:text-slate-300 font-bold text-sm sm:text-base leading-relaxed">{intel?.text}</p>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div className="p-6 bg-white dark:bg-white/5 rounded-2xl border border-slate-100 flex items-center gap-4 shadow-sm hover:border-rose-400 transition-all">
                            <Activity className="w-6 h-6 text-rose-600" />
                            <div>
                                <p className="text-[9px] text-slate-500 font-black uppercase tracking-widest">Medical</p>
                                <p className="text-slate-900 dark:text-white font-black text-sm uppercase">Secure Hubs</p>
                            </div>
                        </div>
                        <div className="p-6 bg-white dark:bg-white/5 rounded-2xl border border-slate-100 flex items-center gap-4 shadow-sm hover:border-rose-400 transition-all">
                            <Phone className="w-6 h-6 text-rose-600" />
                            <div>
                                <p className="text-[9px] text-slate-500 font-black uppercase tracking-widest">Support</p>
                                <p className="text-slate-900 dark:text-white font-black text-sm uppercase">Priority 24/7</p>
                            </div>
                        </div>
                    </div>
                </div>
             )}
          </div>
        </div>
        <div className="lg:col-span-4">
            <div className="bg-slate-950 rounded-[2rem] p-8 shadow-industry text-white space-y-6">
                <h3 className="font-black text-lg leading-tight uppercase tracking-tight">Embassy Reach</h3>
                <p className="text-xs font-bold opacity-70 leading-relaxed">Your Explorer credentials provide direct biological signal sync with local consular offices.</p>
                <button className="w-full py-4 bg-rose-600 text-white rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-rose-700 transition-all">
                    ACCESS POLICY NODE
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};

export default SafetyRadar;
