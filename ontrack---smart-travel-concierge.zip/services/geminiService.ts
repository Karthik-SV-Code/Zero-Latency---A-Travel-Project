
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { ItineraryDay, TransportOption, Citation, VisualScoutResult, UserProfile } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const PRO_MODEL = "gemini-3-pro-preview";
const FLASH_MODEL = "gemini-3-flash-preview";
const LITE_MODEL = "gemini-flash-lite-latest"; 
const TTS_MODEL = "gemini-2.5-flash-preview-tts";
const VEO_MODEL = "veo-3.1-fast-generate-preview";

const apiCache: Record<string, { data: any; timestamp: number }> = {};
const CACHE_TTL = 1000 * 60 * 15;

const getCache = (key: string) => {
  const cached = apiCache[key];
  if (cached && Date.now() - cached.timestamp < CACHE_TTL) return cached.data;
  return null;
};

const setCache = (key: string, data: any) => {
  apiCache[key] = { data, timestamp: Date.now() };
};

export const getReliableImageUrl = (keyword: string = 'travel', size: 'hero' | 'fast' = 'hero') => {
    const clean = keyword.toLowerCase().trim();
    const photoIds: Record<string, string> = {
        'adventure': '1533240332313-0dbf16453ff1',
        'chill': '1554118811-1e0d58224f24',
        'local': '1517248135467-4c7edcad34c4',
        'productive': '1497215728101-856f4ea42174',
        'nature': '1470071459604-3b5ec3a7fe05',
        'city': '1449824913935-59a10b8d2000',
        'beach': '1507525428034-b723cf961d3e',
        'mountain': '1464822759023-fed622ff2c3b',
        'forest': '1441974231531-c6227db76b6e',
        'snow': '1483921020237-2ff51e8e4b22',
        'desert': '1473580044384-7ba9967e16a0',
        'temple': '1548013146-72479768bbaa',
        'cafe': '1495474472287-4d71bcdd2085',
        'dining': '1517248135467-4c7edcad34c4',
        'hotel': '1566073771259-6a8506099945',
        'museum': '1518998053504-527f467f317b',
        'london': '1513635269975-59663e0ac1ad',
        'paris': '1502602898657-3e91760cbb34',
        'tokyo': '1540959733332-eab4deabeeaf',
        'singapore': '1525625230558-23307b4625af',
        'new york': '1496442226666-8d4d0e62e6e9'
    };
    let photoId = '';
    for (const key of Object.keys(photoIds)) {
        if (clean.includes(key)) { photoId = photoIds[key]; break; }
    }
    if (!photoId) photoId = '1506744038136-46273834b3fb';
    return size === 'fast' 
        ? `https://images.unsplash.com/photo-${photoId}?auto=format&fit=crop&q=20&w=300&blur=30`
        : `https://images.unsplash.com/photo-${photoId}?auto=format&fit=crop&q=80&w=1200`;
};

const callGeminiWithRetry = async <T>(fn: () => Promise<T>, retries = 3, delay = 3000): Promise<T> => {
  try { return await fn(); } catch (error: any) {
    const errorStr = JSON.stringify(error).toLowerCase();
    const isRateLimit = errorStr.includes('429') || errorStr.includes('quota') || errorStr.includes('exhausted');
    if (retries > 0 && isRateLimit) {
      await new Promise(resolve => setTimeout(resolve, delay));
      return callGeminiWithRetry(fn, retries - 1, delay * 2);
    }
    throw error;
  }
};

const parseAIResponse = <T>(text: string | undefined, fallback: T): T => {
    if (!text) return fallback;
    try {
        const start = text.indexOf('{');
        const end = text.lastIndexOf('}');
        const arrStart = text.indexOf('[');
        if (arrStart !== -1 && (start === -1 || arrStart < start)) {
            const potentialJson = text.substring(arrStart, text.lastIndexOf(']') + 1);
            return JSON.parse(potentialJson);
        } else if (start !== -1) {
            const potentialJson = text.substring(start, end + 1);
            return JSON.parse(potentialJson);
        }
        return fallback;
    } catch (e) { 
        console.warn("Failed to parse AI JSON response", text);
        return fallback; 
    }
};

export const getLiveTravelAlerts = async (location: string): Promise<{alerts: any[], citations: Citation[]}> => {
    const cacheKey = `alerts-${location}`;
    const cached = getCache(cacheKey);
    if (cached) return cached;

    return callGeminiWithRetry(async () => {
        // We avoid responseMimeType when using googleSearch as it can be unstable
        const response = await ai.models.generateContent({
            model: FLASH_MODEL,
            contents: `Search for current travel news, weather alerts, and important local events in ${location} today. Return the result in a clean JSON format: Array<{title: string, detail: string, severity: 'low'|'medium'|'high'}>. Do not add any conversational text.`,
            config: {
                tools: [{ googleSearch: {} }]
            }
        });
        
        const text = response.text;
        const alerts = parseAIResponse<any[]>(text, []);
        const citations = (response.candidates?.[0]?.groundingMetadata?.groundingChunks || [])
            .filter((c: any) => c.web)
            .map((c: any) => ({ uri: c.web.uri, title: c.web.title }));
        
        const result = { alerts, citations };
        setCache(cacheKey, result);
        return result;
    });
};

export const generateDailyAudioBriefing = async (text: string, persona: string): Promise<string> => {
  return callGeminiWithRetry(async () => {
    const response = await ai.models.generateContent({
      model: TTS_MODEL,
      contents: [{ parts: [{ text: `Persona: ${persona}. Briefing: ${text}` }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: persona === 'scout' ? 'Puck' : 'Kore' } } },
      },
    });
    return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || "";
  });
};

export const generateCinematicTour = async (destination: string): Promise<string> => {
    const prompt = `A 4k cinematic drone shot flying over ${destination}, capturing the essence and high-end travel vibes, sunset lighting, professional photography.`;
    const aiScoped = new GoogleGenAI({ apiKey: process.env.API_KEY });
    let operation = await aiScoped.models.generateVideos({
      model: VEO_MODEL,
      prompt,
      config: { numberOfVideos: 1, resolution: '1080p', aspectRatio: '16:9' }
    });
    while (!operation.done) {
      await new Promise(resolve => setTimeout(resolve, 10000));
      operation = await aiScoped.operations.getVideosOperation({ operation: operation });
    }
    const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
    return `${downloadLink}&key=${process.env.API_KEY}`;
};

export const getSafetyIntelligence = async (location: string): Promise<{ text: string, citations: Citation[] }> => {
    return callGeminiWithRetry(async () => {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: `Current safety alerts, pharmacies, hospitals, and police stations in ${location}. provide high-precision tactical data.`,
            config: { tools: [{ googleMaps: {} }] }
        });
        const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
        const citations = chunks.filter((c: any) => c.maps).map((c: any) => ({ 
            uri: c.maps.uri, 
            title: c.maps.title 
        }));
        return { text: response.text || "No active alerts identified.", citations };
    });
};

export const generatePackingAssistant = async (destination: string, duration: number, style: string) => {
    return callGeminiWithRetry(async () => {
        const response = await ai.models.generateContent({
            model: LITE_MODEL,
            contents: `Packing checklist for ${duration} days in ${destination} for ${style} travel style. Categorize into Essentials, Clothing, Gear, and Tech. JSON: Array<{category: string, items: Array<{item: string, reason: string}>}>`,
            config: { responseMimeType: "application/json" }
        });
        return parseAIResponse<any[]>(response.text, []);
    });
};

export const analyzeVisualScout = async (base64Image: string, mimeType: string): Promise<VisualScoutResult> => {
  return callGeminiWithRetry(async () => {
    const response = await ai.models.generateContent({
      model: FLASH_MODEL,
      contents: { parts: [{ inlineData: { data: base64Image, mimeType } }, { text: "Identify this place/item. Advice: JSON: {identification, context, advice}" }] },
      config: { responseMimeType: "application/json" }
    });
    return parseAIResponse(response.text, { identification: "Unknown Spot", context: "Unknown context", advice: "Try again." });
  });
};

export const getLocationDescription = async (lat: number, lng: number): Promise<string> => {
    return callGeminiWithRetry(async () => {
        const response = await ai.models.generateContent({
            model: LITE_MODEL,
            contents: `City and Country for ${lat}, ${lng}. Format: City, Country.`,
        });
        return response.text?.trim() || "Local Destination";
    });
};

export const generateItinerary = async (destination: string, days: number, user: UserProfile) => {
  return callGeminiWithRetry(async () => {
    const response = await ai.models.generateContent({
      model: PRO_MODEL,
      contents: `Wonderful ${days}-day plan for ${destination}. Style: ${user.preferences.travelStyle}. JSON: {itinerary: Array<{day, weatherForecast, items: Array<{time, activity, type, location}>}>}`,
      config: { tools: [{ googleSearch: {} }], responseMimeType: "application/json" }
    });
    const data = parseAIResponse<{itinerary: ItineraryDay[]}>(response.text, { itinerary: [] });
    const citations = (response.candidates?.[0]?.groundingMetadata?.groundingChunks || []).filter((c: any) => c.web).map((c: any) => ({ uri: c.web.uri, title: c.web.title }));
    return { itinerary: data.itinerary, citations };
  });
};

export const chatWithTravelAssistantStream = async (history: any[], message: string, user: UserProfile, onChunk: (t: string) => void) => {
    const response = await ai.models.generateContentStream({
      model: FLASH_MODEL,
      contents: [...history, { role: 'user', parts: [{ text: message }] }],
      config: { systemInstruction: `Friendly concierge for ${user.name}. Persona: ${user.persona}.` }
    });
    let full = "";
    for await (const chunk of response) { if (chunk.text) { full += chunk.text; onChunk(full); } }
    return full;
};

export const getPersonalizedRecommendations = async (user: UserProfile, currentLocation: string) => {
    return callGeminiWithRetry(async () => {
        const response = await ai.models.generateContent({
            model: LITE_MODEL,
            contents: `3 travel spots for mood (${user.currentMood}) in ${currentLocation}. JSON: Array<{title, reason, visualKeyword, isLocal: boolean}>`,
            config: { responseMimeType: "application/json" }
        });
        return parseAIResponse<any[]>(response.text, []);
    });
};

export const generateTransportOptions = async (source: string, destination: string) => {
    return callGeminiWithRetry(async () => {
        const response = await ai.models.generateContent({
            model: PRO_MODEL,
            contents: `Transport from ${source} to ${destination}. JSON: Array<{id, type, provider, cost, duration, departureTime, arrivalTime}>`,
            config: { tools: [{ googleSearch: {} }], responseMimeType: "application/json" }
        });
        const options = parseAIResponse<TransportOption[]>(response.text, []);
        const citations = (response.candidates?.[0]?.groundingMetadata?.groundingChunks || []).filter((c: any) => c.web).map((c: any) => ({ uri: c.web.uri, title: c.web.title }));
        return { options, citations };
    });
};

export const getExploreRecommendations = async (location: string, category: string) => {
    return callGeminiWithRetry(async () => {
        const response = await ai.models.generateContent({
            model: LITE_MODEL,
            contents: `4 places in ${location} for ${category}. JSON: Array<{title, type, rating, dist, visualKeyword}>`,
            config: { responseMimeType: "application/json" }
        });
        return parseAIResponse<any[]>(response.text, []);
    });
};
