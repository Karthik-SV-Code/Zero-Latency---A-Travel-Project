
import React from 'react';
import { Check, Star, Shield, Zap, Globe, Crown, IndianRupee, Activity, Sparkles } from 'lucide-react';
import { UserType } from '../types';

interface PremiumProps {
    currentType: UserType;
    onUpgrade: (type: UserType) => void;
}

const Premium: React.FC<PremiumProps> = ({ currentType, onUpgrade }) => {
    return (
        <div className="max-w-6xl mx-auto py-10 animate-fade-in">
            <div className="text-center mb-20">
                <div className="flex items-center justify-center gap-3 mb-6">
                    <span className="bg-amber-500/10 text-amber-500 border border-amber-500/20 px-4 py-1 rounded-full text-[10px] font-black uppercase tracking-widest flex items-center shadow-yellow-pulse">
                        <Sparkles className="w-3 h-3 mr-2" /> Elite Expansion Available
                    </span>
                </div>
                <h1 className="text-6xl font-black text-white tracking-tighter mb-4 leading-none">
                    Intelligence <span className="text-gradient-gold">Tiers</span>
                </h1>
                <p className="text-slate-400 text-xl font-medium max-w-2xl mx-auto leading-relaxed">
                    Unlock higher-tier biological synchronization and priority rescue protocols.
                </p>
            </div>

            <div className="grid md:grid-cols-3 gap-10 items-stretch">
                {/* Explorer Plan */}
                <div className="glass-morphism p-12 rounded-[3rem] border border-white/5 flex flex-col group relative overflow-hidden">
                    <div className="w-16 h-16 bg-white/5 rounded-2xl flex items-center justify-center mb-10 group-hover:scale-110 transition-transform border border-white/5">
                        <Globe className="w-8 h-8 text-slate-400" />
                    </div>
                    <h3 className="text-2xl font-black text-white mb-2">Explorer</h3>
                    <div className="mb-10">
                        <span className="text-4xl font-black text-white">₹0</span>
                        <span className="text-slate-500 text-sm font-bold uppercase tracking-widest ml-2">/ mo</span>
                    </div>
                    <ul className="space-y-6 mb-16 flex-1">
                        {['Standard AI Planning', 'Public Itineraries', 'Standard Intel'].map((feat, i) => (
                            <li key={i} className="flex items-center text-sm font-bold text-slate-400">
                                <Check className="w-4 h-4 text-emerald-500 mr-4 shrink-0" /> {feat}
                            </li>
                        ))}
                    </ul>
                    <button 
                        disabled={currentType === UserType.BUDGET}
                        onClick={() => onUpgrade(UserType.BUDGET)}
                        className="w-full py-5 rounded-2xl border-2 border-white/5 font-black text-slate-500 disabled:bg-white/5 transition-all uppercase tracking-widest text-[10px]"
                    >
                        {currentType === UserType.BUDGET ? 'PROTOCOL ACTIVE' : 'SWITCH'}
                    </button>
                </div>

                {/* Nomad Plan */}
                <div className="bg-white p-12 rounded-[3rem] shadow-premium relative flex flex-col transform lg:-translate-y-6 group">
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-amber-500 text-slate-950 px-8 py-2.5 rounded-full text-[10px] font-black tracking-[0.2em] uppercase shadow-yellow-pulse">
                        HIGH FOCUS
                    </div>
                    <div className="w-16 h-16 bg-slate-950 rounded-2xl flex items-center justify-center mb-10 group-hover:rotate-12 transition-transform shadow-xl">
                        <Zap className="w-8 h-8 text-amber-500 fill-amber-500" />
                    </div>
                    <h3 className="text-3xl font-black text-slate-950 mb-2">Nomad</h3>
                    <div className="mb-10">
                        <span className="text-5xl font-black text-slate-950">₹999</span>
                        <span className="text-slate-500 text-sm font-bold uppercase tracking-widest ml-2">/ mo</span>
                    </div>
                    <ul className="space-y-6 mb-16 flex-1">
                        {['Unlimited AI Paths', 'Global Offline Sync', 'Priority Data Node', 'Biometric Itineraries'].map((feat, i) => (
                            <li key={i} className="flex items-center text-sm font-bold text-slate-700">
                                <Check className="w-5 h-5 text-amber-500 mr-4 shrink-0" /> {feat}
                            </li>
                        ))}
                    </ul>
                    <button 
                        disabled={currentType === UserType.NOMAD}
                        onClick={() => onUpgrade(UserType.NOMAD)}
                        className="w-full py-6 rounded-2xl bg-slate-950 text-white font-black shadow-2xl hover:bg-amber-500 hover:text-slate-950 transition-all disabled:opacity-50 uppercase tracking-widest text-xs"
                    >
                        {currentType === UserType.NOMAD ? 'CURRENT HUB' : 'INITIALIZE UPLINK'}
                    </button>
                </div>

                {/* Elite Plan */}
                <div className="glass-morphism p-12 rounded-[3rem] border border-white/5 flex flex-col group relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/5 rounded-full blur-3xl -mr-16 -mt-16"></div>
                    <div className="w-16 h-16 bg-white/5 rounded-2xl flex items-center justify-center mb-10 group-hover:scale-110 transition-transform border border-white/5">
                        <Crown className="w-8 h-8 text-amber-500" />
                    </div>
                    <h3 className="text-2xl font-black text-white mb-2">Elite</h3>
                    <div className="mb-10">
                        <span className="text-4xl font-black text-white">₹2,499</span>
                        <span className="text-slate-500 text-sm font-bold uppercase tracking-widest ml-2">/ mo</span>
                    </div>
                    <ul className="space-y-6 mb-16 flex-1">
                        {['Rescue Protocol Omega', 'VIP Global Concierge', 'Zero Zero Fees', 'Safety Intelligence'].map((feat, i) => (
                            <li key={i} className="flex items-center text-sm font-bold text-slate-400">
                                <Check className="w-4 h-4 text-amber-500 mr-4 shrink-0" /> {feat}
                            </li>
                        ))}
                    </ul>
                    <button 
                        disabled={currentType === UserType.PREMIUM}
                        onClick={() => onUpgrade(UserType.PREMIUM)}
                        className="w-full py-5 rounded-2xl border-2 border-amber-500 text-amber-500 font-black hover:bg-amber-500 hover:text-slate-950 transition-all disabled:opacity-50 uppercase tracking-widest text-[10px]"
                    >
                        {currentType === UserType.PREMIUM ? 'ELITE STATUS' : 'JOIN ELITE'}
                    </button>
                </div>
            </div>

            <div className="mt-32 glass-morphism p-12 rounded-[3rem] border border-white/5 flex flex-col md:flex-row items-center gap-10 shadow-premium">
                <div className="w-24 h-24 bg-white/5 rounded-3xl shadow-xl flex items-center justify-center shrink-0 border border-white/10">
                    <Shield className="w-12 h-12 text-amber-500" />
                </div>
                <div>
                    <h3 className="text-2xl font-black text-white mb-2">Encrypted Intelligence Guarantee</h3>
                    <p className="text-slate-400 font-medium leading-relaxed max-w-3xl">
                        All synchronization plans include end-to-end biological encryption. Your travel logs and neural patterns are never sold. Protocol termination available at any time.
                    </p>
                </div>
            </div>
        </div>
    );
};

export default Premium;
