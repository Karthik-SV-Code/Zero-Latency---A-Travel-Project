
import React, { useState } from 'react';
import { Sparkles, ArrowLeft, Video, AlertCircle, ExternalLink, Key, Loader2 } from 'lucide-react';
import { generateCinematicTour } from '../services/geminiService';

interface VideoTourProps {
  destination: string;
  onBack: () => void;
}

const VideoTour: React.FC<VideoTourProps> = ({ destination, onBack }) => {
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loadingMsg, setLoadingMsg] = useState('');

  const handleGenerate = async () => {
    if (!(window as any).aistudio?.hasSelectedApiKey || !(await (window as any).aistudio.hasSelectedApiKey())) {
        setError("Veo requires a paid API key for cinematic generation.");
        return;
    }
    setLoading(true);
    setError(null);
    setLoadingMsg("Initializing Veo 3.1...");
    try {
        const url = await generateCinematicTour(destination);
        setVideoUrl(url);
    } catch (e: any) {
        setError("Cinematic rendering interrupted.");
    } finally {
        setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 md:space-y-12 animate-fade-in pb-20 px-4">
      <div className="flex items-center justify-between">
        <button onClick={onBack} className="flex items-center gap-3 text-slate-500 hover:text-gold transition-colors font-black uppercase tracking-widest text-[10px]">
            <ArrowLeft className="w-5 h-5" /> Back
        </button>
        <span className="bg-gold/10 text-gold px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-widest border border-gold/20 shadow-gold-glow">
            Veo 3.1 Production Node
        </span>
      </div>
      <div className="glass-morphism rounded-[2.5rem] p-8 md:p-12 flex flex-col items-center text-center gap-10 border border-gold/10 bg-white dark:bg-slate-900/40 shadow-premium">
        {!videoUrl ? (
            <div className="space-y-10 w-full max-w-lg">
                <div className="w-20 h-20 sm:w-24 sm:h-24 bg-slate-950 rounded-[2rem] flex items-center justify-center mx-auto shadow-industry transition-all hover:scale-105">
                    <Video className="w-10 h-10 sm:w-12 sm:h-12 text-gold" />
                </div>
                <div className="space-y-4">
                    <h1 className="text-3xl md:text-4xl font-black text-slate-900 dark:text-white tracking-tighter">Cinematic Tour: {destination}</h1>
                    <p className="text-slate-600 dark:text-slate-400 font-medium text-lg leading-relaxed">
                        Generate a 1080p high-fidelity biological scan of your destination.
                    </p>
                </div>
                {loading ? (
                    <div className="space-y-6 w-full">
                        <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                            <div className="h-full bg-gold animate-shimmer" style={{ width: '40%', backgroundSize: '200% 100%' }}></div>
                        </div>
                        <p className="text-gold font-black text-[10px] sm:text-xs animate-pulse uppercase tracking-[0.2em]">{loadingMsg}</p>
                    </div>
                ) : (
                    <div className="space-y-4 w-full">
                        <button onClick={handleGenerate} className="w-full py-5 bg-slate-950 text-white rounded-2xl font-black text-[12px] uppercase tracking-widest hover:bg-gold hover:text-slate-950 transition-all flex items-center justify-center gap-4 shadow-xl">
                            <Sparkles className="w-5 h-5" /> Initialize Rendering
                        </button>
                        <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest">Est: 120s Production Cycle</p>
                    </div>
                )}
                {error && <div className="p-4 bg-rose-50 text-rose-600 border border-rose-100 rounded-xl text-[11px] font-black uppercase tracking-widest">{error}</div>}
            </div>
        ) : (
            <div className="w-full space-y-10 animate-fade-in">
                <div className="aspect-video rounded-[2rem] overflow-hidden border border-gold/10 bg-black shadow-industry relative group">
                    <video src={videoUrl} controls autoPlay className="w-full h-full object-cover" />
                </div>
                <div className="flex flex-col sm:flex-row gap-4">
                    <button onClick={() => setVideoUrl(null)} className="flex-1 py-4 bg-white text-slate-900 rounded-2xl border border-slate-200 font-black text-[11px] uppercase tracking-widest hover:bg-slate-50 transition-all shadow-sm">
                        New Production
                    </button>
                    <a href={videoUrl} download className="flex-1 py-4 bg-gold text-slate-950 rounded-2xl font-black text-[11px] uppercase tracking-widest hover:opacity-90 transition-all flex items-center justify-center gap-3 shadow-premium">
                        Download Master <ExternalLink className="w-4 h-4" />
                    </a>
                </div>
            </div>
        )}
      </div>
    </div>
  );
};

export default VideoTour;
