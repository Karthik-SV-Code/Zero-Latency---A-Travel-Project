
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { UserProfile } from '../types';
import { Mic, MicOff, Headphones, Activity, Loader2, ArrowLeft, Volume2 } from 'lucide-react';

interface LiveConciergeProps {
  user: UserProfile;
  onBack: () => void;
}

function encode(bytes: Uint8Array) {
  let binary = '';
  for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

function decode(base64: string) {
  const binaryString = atob(base64);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) bytes[i] = binaryString.charCodeAt(i);
  return bytes;
}

async function decodeAudioData(data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const buffer = ctx.createBuffer(numChannels, dataInt16.length / numChannels, sampleRate);
  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < buffer.length; i++) channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
  }
  return buffer;
}

const LiveConcierge: React.FC<LiveConciergeProps> = ({ user, onBack }) => {
  const [isActive, setIsActive] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [transcription, setTranscription] = useState<string[]>([]);

  const sessionRef = useRef<any>(null);
  const audioContextsRef = useRef<{ input: AudioContext; output: AudioContext } | null>(null);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const nextStartTimeRef = useRef(0);

  const startSession = async () => {
    if (isConnecting) return;
    setIsConnecting(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextsRef.current = { input: inputCtx, output: outputCtx };

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setIsActive(true);
            setIsConnecting(false);
            const source = inputCtx.createMediaStreamSource(stream);
            const processor = inputCtx.createScriptProcessor(4096, 1, 1);
            processor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const int16 = new Int16Array(inputData.length);
              for (let i = 0; i < inputData.length; i++) int16[i] = inputData[i] * 32768;
              sessionPromise.then(s => s.sendRealtimeInput({ media: { data: encode(new Uint8Array(int16.buffer)), mimeType: 'audio/pcm;rate=16000' } }));
            };
            source.connect(processor);
            processor.connect(inputCtx.destination);
          },
          onmessage: async (msg: LiveServerMessage) => {
            if (msg.serverContent?.modelTurn?.parts[0]?.inlineData?.data) {
              const base64 = msg.serverContent.modelTurn.parts[0].inlineData.data;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputCtx.currentTime);
              const buffer = await decodeAudioData(decode(base64), outputCtx, 24000, 1);
              const source = outputCtx.createBufferSource();
              source.buffer = buffer;
              source.connect(outputCtx.destination);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              sourcesRef.current.add(source);
              source.onended = () => sourcesRef.current.delete(source);
            }
            if (msg.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => s.stop());
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }
            if (msg.serverContent?.outputTranscription) {
                setTranscription(prev => [...prev.slice(-4), `Concierge: ${msg.serverContent!.outputTranscription!.text}`]);
            }
          },
          onclose: () => stopSession(),
          onerror: () => stopSession()
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } },
          systemInstruction: `You are OnTrack Live, a real-time translation and travel rescue assistant. Help ${user.name}.`,
          outputAudioTranscription: {}
        }
      });
      sessionRef.current = sessionPromise;
    } catch (e) {
      console.error(e);
      setIsConnecting(false);
    }
  };

  const stopSession = () => {
    setIsActive(false);
    setIsConnecting(false);
    sessionRef.current?.then((s: any) => s.close());
    audioContextsRef.current?.input.close();
    audioContextsRef.current?.output.close();
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 md:space-y-12 animate-fade-in pb-20 px-4">
      <div className="flex items-center justify-between">
        <button onClick={onBack} className="flex items-center gap-3 text-slate-500 hover:text-brand-600 transition-colors font-black uppercase tracking-widest text-[10px]">
            <ArrowLeft className="w-5 h-5" /> Back
        </button>
        <span className="bg-brand-50 dark:bg-brand-900/20 text-brand-600 dark:text-brand-400 px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-widest border border-brand-100 dark:border-brand-500/20">
            Tactical Uplink Active
        </span>
      </div>
      <div className="glass-morphism rounded-[2.5rem] p-8 md:p-12 flex flex-col items-center text-center gap-8 relative overflow-hidden border border-brand-100 dark:border-white/5 bg-white dark:bg-slate-900/40 shadow-premium">
        <div className={`w-32 h-32 sm:w-40 sm:h-40 rounded-full flex items-center justify-center transition-all duration-700 relative ${isActive ? 'bg-brand-600 shadow-ontrack scale-110' : 'bg-brand-50 dark:bg-slate-800 border border-brand-100 dark:border-white/10'}`}>
            {isActive && <div className="absolute inset-0 rounded-full border-4 border-brand-500 animate-ping opacity-20"></div>}
            {isActive ? <Volume2 className="w-12 h-12 text-white" /> : <Mic className="w-12 h-12 text-brand-400 dark:text-brand-500" />}
        </div>
        <div className="max-w-lg space-y-4">
            <h1 className="text-3xl md:text-4xl font-black text-slate-900 dark:text-white tracking-tighter">Live Support</h1>
            <p className="text-slate-600 dark:text-slate-400 font-medium text-base sm:text-lg leading-relaxed">
                Connect directly to your local intelligence node for real-time translation and tactical assistance.
            </p>
        </div>
        <div className="w-full flex flex-col gap-4">
            <button 
                onClick={isActive ? stopSession : startSession}
                disabled={isConnecting}
                className={`w-full py-5 rounded-2xl font-black text-[12px] uppercase tracking-widest transition-all flex items-center justify-center gap-4 ${isActive ? 'bg-rose-600 text-white shadow-xl' : 'bg-brand-600 text-white shadow-ontrack hover:bg-brand-700'}`}
            >
                {isConnecting ? <Loader2 className="w-6 h-6 animate-spin" /> : (isActive ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />)}
                {isConnecting ? 'ESTABLISHING...' : (isActive ? 'TERMINATE SESSION' : 'ACTIVATE LIVE LINK')}
            </button>
            {isActive && (
                <div className="p-6 bg-brand-50 dark:bg-slate-950/50 rounded-2xl border border-brand-100 dark:border-white/5 text-left space-y-3 shadow-inner min-h-[150px]">
                    <p className="text-[10px] font-black text-brand-400 uppercase tracking-widest mb-4">Real-time Stream</p>
                    {transcription.map((t, i) => <p key={i} className="text-slate-700 dark:text-slate-300 font-bold text-sm sm:text-base animate-fade-in">{t}</p>)}
                </div>
            )}
        </div>
      </div>
    </div>
  );
};

export default LiveConcierge;
