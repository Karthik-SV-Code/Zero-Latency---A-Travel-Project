
import React, { useState, useEffect, useCallback } from 'react';
import { Search, MapPin, Star, Heart, Loader2, ArrowUpRight, Sparkles, Mountain } from 'lucide-react';
import { getExploreRecommendations, getReliableImageUrl } from '../services/geminiService';
import VisualScout from './VisualScout';

interface ExplorerProps {
    defaultLocation?: string;
}

const ExplorerSkeleton = ({ category }: { category: string }) => {
  const ghostImageUrl = getReliableImageUrl(category.toLowerCase().includes('dining') ? 'dining' : 'nature', 'fast');
  
  return (
    <div className="glass-morphism squircle overflow-hidden border border-slate-200/60 dark:border-white/5 animate-fade-in">
      <div 
        className="h-64 flex items-center justify-center relative overflow-hidden bg-slate-100 dark:bg-slate-900"
      >
          <div 
            className="absolute inset-0 z-0 bg-cover bg-center transition-opacity duration-1000" 
            style={{ backgroundImage: `url(${ghostImageUrl})` }}
          />
          <div className="absolute inset-0 bg-slate-950/30 dark:bg-black/50 z-10" />
          <div className="relative z-20 flex flex-col items-center">
             <Mountain className="w-12 h-12 text-white/50 mb-3" />
             <span className="text-[10px] font-black text-white/40 uppercase tracking-[0.2em]">Searching for {category}...</span>
          </div>
          <div className="absolute inset-0 skeleton-placeholder z-30 opacity-20" />
      </div>
      <div className="p-10 space-y-6">
        <div className="flex justify-between items-start gap-4">
          <div className="h-7 bg-slate-100 dark:bg-slate-800/50 rounded w-2/3" />
          <div className="h-7 bg-slate-100 dark:bg-slate-800/50 rounded w-12" />
        </div>
        <div className="h-3 bg-slate-100 dark:bg-slate-800/30 rounded w-1/2" />
        <div className="h-14 bg-slate-100 dark:bg-slate-800/30 rounded-2xl w-full" />
      </div>
    </div>
  );
};

const Explorer: React.FC<ExplorerProps> = ({ defaultLocation = 'Mumbai, India' }) => {
    const [filter, setFilter] = useState('All');
    const [currentLocation, setCurrentLocation] = useState(defaultLocation);
    const [places, setPlaces] = useState<any[]>([]);
    const [loading, setLoading] = useState(false);
    const [searchInput, setSearchInput] = useState(defaultLocation);

    const filters = ['All', 'Cafes & Work', 'Dining', 'Local Sights', 'Relaxation'];

    useEffect(() => {
        if (defaultLocation !== currentLocation) {
            setCurrentLocation(defaultLocation);
            setSearchInput(defaultLocation);
        }
    }, [defaultLocation]);

    const fetchPlaces = useCallback(async () => {
        setLoading(true);
        try {
            const data = await getExploreRecommendations(currentLocation, filter);
            const verifiedData = Array.isArray(data) ? data : [];
            const augmentedData = verifiedData.map((place: any) => ({
                ...place,
                img: getReliableImageUrl(place.visualKeyword || place.title || filter, 'hero'),
                fastImg: getReliableImageUrl(place.visualKeyword || place.title || filter, 'fast')
            }));
            setPlaces(augmentedData);
        } catch (e) {
            setPlaces([]);
        } finally {
            setLoading(false);
        }
    }, [currentLocation, filter]);

    useEffect(() => { fetchPlaces(); }, [fetchPlaces]);

    return (
        <div className="space-y-12 animate-fade-in pb-20">
            <VisualScout />
            <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-10">
                <div className="flex-1">
                    <h1 className="text-5xl font-black text-slate-900 dark:text-white tracking-tighter leading-none mb-4 font-display">Local Discoveries</h1>
                    <p className="text-slate-500 dark:text-slate-400 font-medium text-lg">Curated recommendations for you in <span className="text-indigo-600 dark:text-amber-500 font-bold">{currentLocation}</span>.</p>
                </div>
                <div className="w-full md:max-w-md">
                     <form onSubmit={(e) => { e.preventDefault(); setCurrentLocation(searchInput); }} className="flex items-center glass-morphism border border-slate-200 dark:border-white/5 rounded-3xl px-6 py-4 shadow-xl focus-within:ring-2 focus-within:ring-indigo-600/10 dark:focus-within:ring-amber-500/10 transition-all">
                        <MapPin className="w-6 h-6 text-indigo-600 dark:text-amber-500 mr-4" />
                        <input 
                            type="text" 
                            value={searchInput}
                            onChange={(e) => setSearchInput(e.target.value)}
                            className="bg-transparent w-full outline-none text-slate-900 dark:text-white font-bold text-lg"
                            placeholder="Change location..."
                        />
                        <button type="submit" className="text-[11px] font-black bg-indigo-600 dark:bg-white text-white dark:text-slate-950 px-6 py-2.5 rounded-xl ml-4 hover:opacity-90 transition-colors uppercase tracking-widest">Update</button>
                     </form>
                </div>
            </div>

            <div className="flex gap-4 overflow-x-auto pb-6 scrollbar-hide">
                {filters.map(f => (
                    <button key={f} onClick={() => setFilter(f)} className={`px-8 py-3.5 rounded-2xl text-[11px] font-black uppercase tracking-[0.2em] transition-all border ${filter === f ? 'text-white dark:text-slate-950 bg-indigo-600 dark:bg-white border-transparent shadow-xl' : 'text-slate-500 dark:text-slate-400 bg-white dark:bg-white/5 border-slate-200 dark:border-transparent hover:border-slate-300 dark:hover:bg-white/10'}`}>
                        {f}
                    </button>
                ))}
            </div>

            {loading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
                    <ExplorerSkeleton category={filter} />
                    <ExplorerSkeleton category={filter} />
                    <ExplorerSkeleton category={filter} />
                    <ExplorerSkeleton category={filter} />
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
                    {places.map((place, idx) => (
                        <div key={idx} className="group glass-morphism squircle overflow-hidden hover:shadow-2xl transition-all duration-500 cursor-pointer border border-slate-200/60 dark:border-white/5">
                            <div className="relative h-64 overflow-hidden bg-slate-100 dark:bg-slate-900">
                                <div 
                                    className="absolute inset-0 z-0 bg-cover bg-center" 
                                    style={{ backgroundImage: `url(${place.fastImg})` }}
                                />
                                <img 
                                    src={place.img} 
                                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-[2s] image-reveal relative z-10" 
                                    alt={place.title}
                                    onLoad={(e) => (e.target as HTMLImageElement).classList.add('loaded')}
                                    onError={(e) => {
                                        (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&q=80&w=1200';
                                    }}
                                />
                                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-60 dark:opacity-100 z-20" />
                                <div className="absolute top-6 right-6 p-3 bg-white/80 dark:bg-slate-950/60 backdrop-blur-md rounded-2xl text-slate-400 hover:text-red-500 border border-black/5 dark:border-white/10 transition-colors shadow-xl z-30">
                                    <Heart className="w-5 h-5" />
                                </div>
                            </div>
                            <div className="p-10">
                                <div className="flex justify-between items-start mb-4 gap-4">
                                    <h3 className="font-bold text-slate-900 dark:text-white text-xl font-display leading-tight group-hover:text-indigo-600 dark:group-hover:text-amber-500 transition-colors">{place.title}</h3>
                                    <div className="flex items-center text-[10px] font-black text-indigo-600 dark:text-amber-500 bg-indigo-600/10 dark:bg-amber-500/10 px-3 py-1.5 rounded-xl border border-indigo-600/20 dark:border-amber-500/20 shadow-sm shrink-0">
                                        <Star className="w-3.5 h-3.5 fill-indigo-600 dark:fill-amber-500 mr-2" /> {place.rating || '4.8'}
                                    </div>
                                </div>
                                <div className="flex items-center text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-widest mb-10 gap-3">
                                    <span>{place.type}</span>
                                    <div className="w-1.5 h-1.5 bg-slate-300 dark:bg-slate-800 rounded-full"></div>
                                    <span>{place.dist} away</span>
                                </div>
                                <button className="w-full py-5 bg-slate-50 dark:bg-white/5 text-slate-900 dark:text-white rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] hover:bg-indigo-600 dark:hover:bg-white hover:text-white dark:hover:text-slate-950 transition-all duration-500 flex items-center justify-center gap-3">
                                    EXPLORE SPOT <ArrowUpRight className="w-5 h-5" />
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default Explorer;
