
import React, { useState } from 'react';
import { Camera, X, Loader2, Sparkles, Navigation, Globe } from 'lucide-react';
import { analyzeVisualScout } from '../services/geminiService';
import { VisualScoutResult } from '../types';

const VisualScout: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [image, setImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<VisualScoutResult | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImage(reader.result as string);
        processImage(reader.result as string, file.type);
      };
      reader.readAsDataURL(file);
    }
  };

  const processImage = async (base64: string, mime: string) => {
    setLoading(true);
    try {
      const data = base64.split(',')[1];
      const res = await analyzeVisualScout(data, mime);
      setResult(res);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) {
    return (
      <button 
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-28 w-16 h-16 bg-amber-500 text-slate-950 rounded-full flex items-center justify-center shadow-yellow-pulse hover:scale-110 active:scale-95 transition-all z-[100] group border-4 border-slate-950 dark:border-slate-950"
      >
        <Camera className="w-7 h-7" />
        <span className="absolute bottom-20 right-0 bg-white dark:bg-slate-900 text-slate-950 dark:text-white px-5 py-2.5 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] opacity-0 group-hover:opacity-100 transition-all duration-500 whitespace-nowrap shadow-premium translate-y-2 group-hover:translate-y-0 border border-slate-200 dark:border-white/10">
            Activate Visual Scout
        </span>
      </button>
    );
  }

  return (
    <div className="fixed inset-0 z-[200] bg-slate-950/90 backdrop-blur-2xl flex items-center justify-center p-8 animate-fade-in">
      <div className="glass-morphism squircle shadow-premium max-w-2xl w-full overflow-hidden flex flex-col max-h-[90vh] border border-white/10">
        <div className="p-10 border-b border-white/5 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <div className="w-16 h-16 bg-white/5 rounded-2xl flex items-center justify-center border border-white/10">
              <Sparkles className="w-8 h-8 text-amber-500" />
            </div>
            <div>
              <h3 className="font-black text-2xl text-white tracking-tighter leading-none mb-1">Visual Scout AI</h3>
              <p className="text-[10px] text-slate-500 font-black uppercase tracking-[0.3em]">Neural Vision Interface</p>
            </div>
          </div>
          <button onClick={() => { setIsOpen(false); setImage(null); setResult(null); }} className="p-3 text-slate-400 hover:text-white transition-colors"><X className="w-8 h-8" /></button>
        </div>

        <div className="flex-1 overflow-y-auto p-10 space-y-10 scrollbar-hide">
          {!image ? (
            <div className="h-80 border-4 border-dashed border-white/5 rounded-[2.5rem] flex flex-col items-center justify-center text-slate-700 hover:border-amber-500/50 hover:text-amber-500 transition-all group relative overflow-hidden bg-white/[0.02]">
              <input type="file" accept="image/*" onChange={handleFileChange} className="absolute inset-0 opacity-0 cursor-pointer z-10" />
              <Camera className="w-20 h-20 mb-6 group-hover:scale-110 transition-transform duration-500" />
              <p className="font-black uppercase tracking-[0.3em] text-xs">Awaiting Visual Input</p>
              <p className="text-[10px] mt-3 font-bold opacity-40">LANDMARKS • MENUS • SIGNS</p>
            </div>
          ) : (
            <div className="space-y-10 animate-fade-in">
              <div className="relative rounded-[2.5rem] overflow-hidden aspect-video shadow-premium border border-white/5">
                <img src={image} className="w-full h-full object-cover" />
                {loading && (
                  <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-md flex flex-col items-center justify-center text-white">
                    <Loader2 className="w-16 h-16 animate-spin text-amber-500 mb-6" />
                    <p className="font-black uppercase tracking-[0.4em] text-[10px] animate-pulse">Analyzing Biological Patterns</p>
                  </div>
                )}
              </div>

              {result && (
                <div className="space-y-8 animate-fade-in pb-4">
                  <div className="p-8 bg-white/5 rounded-[2rem] border border-white/5 shadow-inner">
                    <h4 className="text-[10px] font-black text-amber-500 uppercase tracking-[0.3em] mb-4 flex items-center gap-3">
                       <Globe className="w-4 h-4" /> NODE IDENTIFIED
                    </h4>
                    <p className="text-3xl font-black text-white leading-tight tracking-tighter">{result.identification}</p>
                  </div>
                  
                  <div className="space-y-6">
                    <div>
                      <h4 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] mb-4">Contextual Intel</h4>
                      <p className="text-lg font-medium text-slate-400 leading-relaxed">{result.context}</p>
                    </div>
                    <div className="p-8 bg-amber-500 text-slate-950 rounded-[2rem] shadow-yellow-pulse">
                      <h4 className="text-[10px] font-black opacity-50 uppercase tracking-[0.3em] mb-3">Tactical Advice</h4>
                      <p className="text-xl font-black leading-tight tracking-tight">{result.advice}</p>
                    </div>
                  </div>

                  <div className="flex gap-6 pt-6">
                    <button className="flex-1 py-5 bg-white text-slate-950 rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] hover:bg-amber-500 transition-all duration-500 flex items-center justify-center gap-4 shadow-premium">
                      <Navigation className="w-5 h-5" /> RE-ROUTE HERE
                    </button>
                    <button onClick={() => { setImage(null); setResult(null); }} className="flex-1 py-5 glass-morphism text-white rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] hover:bg-white/10 transition-all">
                      SCAN NEW NODE
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default VisualScout;
