
import React, { useState, useRef } from 'react';
import { Play, Pause, Loader2, Headphones } from 'lucide-react';
import { generateDailyAudioBriefing } from '../services/geminiService';
import { UserProfile } from '../types';

interface DailyBriefingProps {
  dayText: string;
  user: UserProfile;
}

// Manually implement base64 decoding as per Gemini API raw PCM guidelines
function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

// Manually implement PCM decoding since it has no header and is not a standard web file format
async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const DailyBriefing: React.FC<DailyBriefingProps> = ({ dayText, user }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [loading, setLoading] = useState(false);
  const [audioBuffer, setAudioBuffer] = useState<AudioBuffer | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const sourceRef = useRef<AudioBufferSourceNode | null>(null);

  const handlePlay = async () => {
    // If we already have the decoded buffer, just play/pause
    if (audioBuffer) {
      if (isPlaying) {
        sourceRef.current?.stop();
        setIsPlaying(false);
      } else {
        const ctx = audioContextRef.current || new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        audioContextRef.current = ctx;
        const source = ctx.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(ctx.destination);
        source.onended = () => setIsPlaying(false);
        source.start(0);
        sourceRef.current = source;
        setIsPlaying(true);
      }
      return;
    }

    setLoading(true);
    try {
      const base64Audio = await generateDailyAudioBriefing(dayText, user.persona);
      if (base64Audio) {
        // Initialize AudioContext with 24kHz sample rate as expected by Gemini TTS
        const ctx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        audioContextRef.current = ctx;
        
        const decodedBytes = decode(base64Audio);
        const buffer = await decodeAudioData(decodedBytes, ctx, 24000, 1);
        setAudioBuffer(buffer);
        
        const source = ctx.createBufferSource();
        source.buffer = buffer;
        source.connect(ctx.destination);
        source.onended = () => setIsPlaying(false);
        source.start(0);
        sourceRef.current = source;
        setIsPlaying(true);
      }
    } catch (e) {
      console.error("Audio briefing failed:", e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-slate-900 dark:bg-slate-900 rounded-3xl p-6 flex items-center justify-between border border-slate-800 dark:border-slate-800 shadow-xl animate-fade-in transition-all">
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 bg-indigo-600 dark:bg-brand-600 rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-600/20">
          <Headphones className="w-6 h-6 text-white" />
        </div>
        <div>
          <h4 className="text-white font-black text-sm capitalize">{user.persona} Briefing</h4>
          <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mt-0.5">AI Professional Voice</p>
        </div>
      </div>
      <div className="flex items-center gap-6">
        {isPlaying && (
          <div className="flex gap-1 items-end h-4">
            {[1,2,3,4,5].map(i => (
              <div key={i} className="w-1 bg-amber-500 animate-pulse" style={{ height: `${Math.random() * 100}%`, animationDelay: `${i * 100}ms` }} />
            ))}
          </div>
        )}
        <button onClick={handlePlay} disabled={loading} className="w-12 h-12 bg-white text-slate-900 rounded-full flex items-center justify-center hover:bg-amber-500 hover:text-slate-950 transition-all shadow-xl active:scale-90 disabled:opacity-50">
          {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : (isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-1" />)}
        </button>
      </div>
    </div>
  );
};

export default DailyBriefing;
