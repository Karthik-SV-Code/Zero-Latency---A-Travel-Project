import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { UserProfile, AppView, TravelMood } from '../types';
import { 
  Search, Loader2, Sparkles, Zap, Heart, Coffee, 
  Compass, GraduationCap, ArrowRight, PlayCircle,
  Activity, Navigation, AlertCircle, Map as MapIcon, Mic, Video, ShieldAlert, ShoppingBag, Globe, Info
} from 'lucide-react';
import { getLocationDescription, getPersonalizedRecommendations, getReliableImageUrl, getLiveTravelAlerts } from '../services/geminiService';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

const RecommendationSkeleton = ({ mood }: { mood: TravelMood }) => {
  const ghostImageUrl = getReliableImageUrl(mood, 'fast');
  return (
    <div className="glass-morphism rounded-[2.5rem] overflow-hidden border border-slate-200/50 dark:border-white/5 animate-fade-in transition-all bg-white/50 dark:bg-slate-900/50">
      <div className="h-52 sm:h-64 flex items-center justify-center relative overflow-hidden bg-slate-100 dark:bg-slate-900">
          <div className="absolute inset-0 z-0 bg-cover bg-center grayscale opacity-30" style={{ backgroundImage: `url(${ghostImageUrl})` }} />
          <div className="relative z-20 flex flex-col items-center">
             <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center mb-4 border border-white/30">
               <MapIcon className="w-6 h-6 text-white/50" />
             </div>
             <span className="text-[10px] font-black text-slate-400 dark:text-white/40 uppercase tracking-[0.2em]">Synthesizing {mood} routes...</span>
          </div>
      </div>
      <div className="p-8 sm:p-10 space-y-4">
        <div className="h-6 bg-slate-100 dark:bg-slate-800/50 rounded-xl w-3/4 animate-pulse" />
        <div className="space-y-3">
          <div className="h-3 bg-slate-100 dark:bg-slate-800/30 rounded-lg w-full animate-pulse" />
          <div className="h-3 bg-slate-100 dark:bg-slate-800/30 rounded-lg w-5/6 animate-pulse" />
        </div>
      </div>
    </div>
  );
};

interface DashboardProps {
  user: UserProfile;
  onChangeView: (view: AppView) => void;
  onUpdateProfile: (data: Partial<UserProfile>) => void;
  onPlanTrip: (destination: string, origin?: string) => void;
  isFullscreen?: boolean;
}

const Dashboard: React.FC<DashboardProps> = ({ user, onChangeView, onUpdateProfile, onPlanTrip, isFullscreen }) => {
  const [origin, setOrigin] = useState('Mumbai, IN');
  const [recommendations, setRecommendations] = useState<any[]>([]);
  const [loadingRecs, setLoadingRecs] = useState(true);
  const [alerts, setAlerts] = useState<any[]>([]);
  const [alertCitations, setAlertCitations] = useState<any[]>([]);
  const [loadingAlerts, setLoadingAlerts] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const pointsData = useMemo(() => [
      { name: 'Jan', pts: 4200 },
      { name: 'Feb', pts: 4800 },
      { name: 'Mar', pts: 5200 },
      { name: 'Apr', pts: 7800 },
      { name: 'May', pts: 8900 },
      { name: 'Jun', pts: 12500 },
  ], []);

  const fetchRecs = useCallback(async () => {
    setLoadingRecs(true);
    setError(null);
    try {
        const data = await getPersonalizedRecommendations(user, origin);
        setRecommendations(Array.isArray(data) ? data : []);
    } catch (err: any) {
        setError('Intelligence node temporarily offline.');
    } finally {
        setLoadingRecs(false);
    }
  }, [user.preferences.travelStyle, user.currentMood, origin]);

  const fetchAlerts = useCallback(async () => {
    setLoadingAlerts(true);
    try {
        const { alerts, citations } = await getLiveTravelAlerts(origin);
        setAlerts(alerts);
        setAlertCitations(citations);
    } catch (err) {
        console.error("Alerts fetch failed");
    } finally {
        setLoadingAlerts(false);
    }
  }, [origin]);

  useEffect(() => {
    fetchRecs();
    fetchAlerts();
  }, [fetchRecs, fetchAlerts]);

  const moods: {id: TravelMood, label: string, icon: any, activeColor: string}[] = useMemo(() => [
      { id: 'chill', label: 'Chill', icon: Coffee, activeColor: 'bg-indigo-600 text-white shadow-ontrack' },
      { id: 'adventure', label: 'Adventure', icon: Compass, activeColor: 'bg-gold text-slate-950 shadow-gold-glow' },
      { id: 'productive', label: 'Work', icon: GraduationCap, activeColor: 'bg-slate-950 text-white dark:bg-slate-100 dark:text-slate-950 shadow-xl' },
      { id: 'local', label: 'Local', icon: Heart, activeColor: 'bg-emerald-600 text-white shadow-lg' }
  ], []);

  return (
    <div className="space-y-12 md:space-y-20 animate-fade-in pb-24 px-1">
      {/* Hero Section */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-12">
          <div className="max-w-3xl w-full space-y-6">
            <div className="inline-flex items-center gap-2.5 px-4 py-2 bg-brand-600/5 dark:bg-brand-500/10 rounded-full border border-brand-100 dark:border-brand-500/20 shadow-sm animate-fade-in">
                <Sparkles className="w-3.5 h-3.5 text-brand-600 dark:text-brand-400" />
                <span className="text-[10px] font-black text-brand-600 dark:text-brand-400 uppercase tracking-widest">Global Intelligence Uplink: STABLE</span>
            </div>
            <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black font-display text-slate-900 dark:text-white tracking-tighter leading-[1.05] drop-shadow-sm">
                Redefining <br /> <span className="text-gradient-indigo">Travel Clarity.</span>
            </h1>
            <p className="text-slate-500 dark:text-slate-400 font-semibold text-lg sm:text-xl md:text-2xl leading-relaxed max-w-xl opacity-80">
                Tailored planning for elite nomads. Real-time rescue protocols and high-fidelity logistics.
            </p>
          </div>
          
          <div className={`
              w-full p-2 bg-white dark:bg-slate-800/30 rounded-[2rem] border border-slate-100 dark:border-white/5 
              shadow-premium transition-all duration-700
              ${isFullscreen 
                  ? 'lg:w-auto grid grid-cols-2 md:grid-cols-4 gap-2 overflow-visible' 
                  : 'lg:w-auto flex items-center gap-1.5 overflow-x-auto scrollbar-hide'
              }
          `}>
             {moods.map((m) => (
                 <button 
                    key={m.id}
                    onClick={() => onUpdateProfile({ currentMood: m.id })}
                    className={`
                        whitespace-nowrap flex items-center justify-center gap-3 px-6 sm:px-8 py-3.5 rounded-2xl text-[12px] font-black transition-all duration-500 cubic-bezier(0.4, 0, 0.2, 1)
                        ${user.currentMood === m.id ? `${m.activeColor} scale-[1.05]` : 'text-slate-400 hover:text-brand-600 hover:bg-brand-50/50 dark:hover:bg-white/5'}
                        ${isFullscreen ? 'w-full' : ''}
                    `}
                 >
                    <m.icon className={`w-4.5 h-4.5 transition-transform duration-500 ${user.currentMood === m.id ? 'rotate-12' : ''}`} />
                    <span>{m.label}</span>
                 </button>
             ))}
          </div>
      </div>

      {/* Primary Action Hub */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 sm:gap-8">
          {[
            { id: AppView.TRANSLATOR, label: 'Live Concierge', desc: 'Tactical rescue uplink.', icon: Mic, bg: 'bg-indigo-600', text: 'text-white' },
            { id: AppView.TOUR, label: 'Cinematic Tours', desc: 'Veo 3.1 destination scans.', icon: Video, bg: 'bg-slate-950', text: 'text-white', iconColor: 'text-gold' },
            { id: AppView.SAFETY, label: 'Safety Radar', desc: 'Local threat monitoring.', icon: ShieldAlert, bg: 'bg-rose-600', text: 'text-white' },
            { id: AppView.PACKING, label: 'Packing Scout', desc: 'Neural gear simulations.', icon: ShoppingBag, bg: 'bg-emerald-600', text: 'text-white' },
          ].map((action, i) => (
            <button 
                key={i}
                onClick={() => onChangeView(action.id)} 
                className={`group relative overflow-hidden h-60 sm:h-72 p-8 sm:p-10 rounded-[2.5rem] ${action.bg} ${action.text} text-left shadow-xl hover:-translate-y-2 hover:shadow-2xl transition-all duration-500`}
            >
                <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-3xl -mr-16 -mt-16 group-hover:scale-150 transition-transform duration-1000"></div>
                <action.icon className={`w-10 h-10 sm:w-12 sm:h-12 mb-8 ${action.iconColor || 'text-white'} group-hover:scale-110 transition-transform`} />
                <h3 className="text-xl sm:text-2xl font-black mb-2 leading-tight tracking-tight">{action.label}</h3>
                <p className="text-white/70 text-sm font-medium leading-relaxed">{action.desc}</p>
                <div className="absolute bottom-10 right-10 opacity-0 group-hover:opacity-100 transition-opacity translate-x-4 group-hover:translate-x-0 transition-transform">
                   <ArrowRight className="w-6 h-6" />
                </div>
            </button>
          ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
          {/* Main Content Area */}
          <div className="lg:col-span-8 space-y-12">
              <div className="flex items-center justify-between px-2">
                  <h2 className="text-2xl sm:text-3xl font-black font-display text-slate-900 dark:text-white flex items-center gap-4">
                      <Sparkles className="w-8 h-8 text-gold drop-shadow-sm" /> Personalized Recon
                  </h2>
              </div>

              {loadingRecs ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      <RecommendationSkeleton mood={user.currentMood} />
                      <RecommendationSkeleton mood={user.currentMood} />
                  </div>
              ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      {recommendations.map((rec, i) => (
                          <div key={i} onClick={() => onPlanTrip && onPlanTrip(rec.title)} className="bg-white dark:bg-slate-900/40 glass-morphism rounded-[3rem] overflow-hidden hover:-translate-y-2 transition-all duration-500 group cursor-pointer border border-slate-100 dark:border-white/5 shadow-premium hover:shadow-[0_20px_60px_-15px_rgba(79,70,229,0.15)]">
                              <div className="h-60 sm:h-72 relative overflow-hidden bg-slate-100 dark:bg-slate-800">
                                  <img loading="lazy" src={getReliableImageUrl(`${rec.visualKeyword || rec.title}`, 'hero')} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-[3s] image-reveal relative z-10" alt={rec.title} onLoad={(e) => (e.target as HTMLImageElement).classList.add('loaded')} />
                                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/20 to-transparent z-20 opacity-80" />
                                  <div className="absolute bottom-8 left-8 pr-8 z-30">
                                      <h3 className="text-2xl sm:text-3xl font-black font-display text-white mb-2 tracking-tight">{rec.title}</h3>
                                      <div className="flex items-center gap-2">
                                          <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                                          <span className="text-[10px] font-black text-white/60 uppercase tracking-widest">Optimal Node Reachable</span>
                                      </div>
                                  </div>
                              </div>
                              <div className="p-8 sm:p-10">
                                  <p className="text-slate-600 dark:text-slate-400 text-base sm:text-lg leading-relaxed mb-10 line-clamp-3 font-medium opacity-90">{rec.reason}</p>
                                  <div className="flex items-center justify-between pt-8 border-t border-slate-100 dark:border-white/5">
                                      <span className="text-[11px] font-black text-brand-600 dark:text-brand-400 uppercase tracking-widest">Access Tactical Data</span>
                                      <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-brand-50 dark:bg-brand-900/20 flex items-center justify-center text-brand-600 group-hover:bg-brand-600 group-hover:text-white transition-all duration-300 shadow-sm">
                                        <ArrowRight className="w-5 h-5" />
                                      </div>
                                  </div>
                              </div>
                          </div>
                      ))}
                  </div>
              )}

              {/* Performance Chart */}
              <div className="glass-morphism rounded-[3rem] p-10 md:p-14 border border-slate-100 dark:border-white/5 bg-white dark:bg-slate-900/30 shadow-premium">
                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-8 mb-12">
                      <div className="space-y-2">
                          <h3 className="text-2xl sm:text-3xl font-black font-display text-slate-900 dark:text-white flex items-center gap-4">
                              <Activity className="w-8 h-8 text-brand-600" /> Platform Velocity
                          </h3>
                          <p className="text-slate-400 text-sm font-bold uppercase tracking-widest">Nomadic Point Accrual Cycle</p>
                      </div>
                      <div className="px-6 py-3 bg-brand-50 dark:bg-brand-900/30 rounded-2xl border border-brand-100 dark:border-brand-500/20 shadow-sm">
                          <span className="text-brand-600 dark:text-brand-400 font-black text-xl sm:text-2xl">{user.loyaltyPoints.toLocaleString()} <span className="text-[12px] uppercase opacity-50 ml-1">Pts</span></span>
                      </div>
                  </div>
                  <div className="h-[280px] sm:h-[350px] w-full">
                      <ResponsiveContainer width="100%" height="100%">
                          <AreaChart data={pointsData}>
                              <defs>
                                  <linearGradient id="colorPts" x1="0" y1="0" x2="0" y2="1">
                                      <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.2}/>
                                      <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                                  </linearGradient>
                              </defs>
                              <XAxis dataKey="name" stroke="#94a3b8" fontSize={11} fontWeight={700} tickLine={false} axisLine={false} dy={10} />
                              <YAxis hide />
                              <Tooltip contentStyle={{ borderRadius: '24px', border: 'none', boxShadow: '0 20px 40px rgba(0,0,0,0.1)', padding: '16px' }} />
                              <Area type="monotone" dataKey="pts" stroke="#4f46e5" strokeWidth={5} fillOpacity={1} fill="url(#colorPts)" />
                          </AreaChart>
                      </ResponsiveContainer>
                  </div>
              </div>
          </div>

          {/* Sidebar Area */}
          <div className="lg:col-span-4 space-y-10">
              <div className="glass-morphism rounded-[3rem] p-10 border border-slate-100 dark:border-white/5 bg-white dark:bg-slate-900/30 shadow-premium">
                  <h4 className="text-[11px] font-black text-brand-600 dark:text-brand-400 uppercase tracking-[0.2em] flex items-center gap-3 mb-10">
                      <Globe className="w-5 h-5" /> Global Intel Node
                  </h4>
                  {loadingAlerts ? (
                      <div className="space-y-8">
                          {[1,2,3,4].map(i => (
                            <div key={i} className="space-y-3">
                                <div className="h-4 bg-slate-100 dark:bg-slate-800 rounded-lg w-full animate-pulse" />
                                <div className="h-3 bg-slate-100 dark:bg-slate-800/50 rounded-lg w-2/3 animate-pulse" />
                            </div>
                          ))}
                      </div>
                  ) : (
                      <div className="space-y-10">
                          {alerts.slice(0, 4).map((alert, idx) => (
                              <div key={idx} className="group cursor-default">
                                  <div className="flex items-center gap-3 mb-3">
                                      <div className={`w-2 h-2 rounded-full ${alert.severity === 'high' ? 'bg-rose-500 animate-pulse' : 'bg-brand-500'}`} />
                                      <h5 className="text-[14px] font-black text-slate-900 dark:text-white leading-tight uppercase tracking-tight group-hover:text-brand-600 transition-colors">{alert.title}</h5>
                                  </div>
                                  <p className="text-[13px] text-slate-500 dark:text-slate-400 font-semibold leading-relaxed line-clamp-2 opacity-90">{alert.detail}</p>
                              </div>
                          ))}
                      </div>
                  )}
              </div>

              {/* Promo Card */}
              <div className="bg-slate-950 rounded-[3rem] p-10 sm:p-12 shadow-industry relative overflow-hidden group">
                  <div className="absolute top-0 right-0 w-64 h-64 bg-brand-600/20 rounded-full blur-[80px] -mr-32 -mt-32 group-hover:scale-125 transition-transform duration-1000"></div>
                  <div className="relative z-10 text-white flex flex-col h-full">
                      <div className="w-14 h-14 bg-brand-600 rounded-2xl flex items-center justify-center mb-10 shadow-ontrack group-hover:rotate-6 transition-transform">
                          <Activity className="w-7 h-7 text-white" />
                      </div>
                      <h3 className="text-3xl font-black font-display mb-4 tracking-tight leading-tight">Elite Ledger</h3>
                      <p className="text-base text-slate-400 mb-12 font-medium leading-relaxed italic opacity-80">
                          "Advanced computational archival and priority rescue for high-performance nomads."
                      </p>
                      <button onClick={() => onChangeView(AppView.EXPLORER)} className="w-full py-5 bg-white text-slate-950 rounded-2xl font-black text-[12px] hover:bg-gold transition-all duration-300 flex items-center justify-center gap-3 uppercase tracking-widest shadow-xl">
                          Access Global Grid <Navigation className="w-4 h-4" />
                      </button>
                  </div>
              </div>
          </div>
      </div>
    </div>
  );
};

export default Dashboard;