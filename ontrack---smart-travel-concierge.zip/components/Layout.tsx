import React, { useState } from 'react';
import { AppView, UserProfile } from '../types';
import {
  Map, MessageSquare,
  LayoutDashboard, Activity, Zap, MapPinned, Users, X, Mic, Video, ShieldAlert, ShoppingBag, Menu, Globe, Maximize, Minimize
} from 'lucide-react';
import ChatAssistant from './ChatAssistant';
import ThemeToggle from './ThemeToggle';

interface LayoutProps {
  children: React.ReactNode;
  currentView: AppView;
  onChangeView: (view: AppView) => void;
  user: UserProfile;
  onLogout: () => void;
  isDarkMode: boolean;
  onToggleTheme: () => void;
  isFullscreen: boolean;
}

const Layout: React.FC<LayoutProps> = ({ children, currentView, onChangeView, user, onLogout, isDarkMode, onToggleTheme, isFullscreen }) => {
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch((e) => {
        console.error(`Error attempting to enable full-screen mode: ${e.message}`);
      });
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen();
      }
    }
  };

  const navItems = [
    { id: AppView.DASHBOARD, label: 'Explore', icon: LayoutDashboard },
    { id: AppView.PLANNER, label: 'Planner', icon: MapPinned },
    { id: AppView.EXPLORER, label: 'Discover', icon: Map },
    { id: AppView.TRANSLATOR, label: 'Tactical', icon: Mic },
  ];

  const toggleChat = () => setIsChatOpen(!isChatOpen);
  const toggleMobileMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);

  const handleNavClick = (view: AppView) => {
    onChangeView(view);
    setIsMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen flex flex-col font-sans relative selection:bg-brand-600/20 transition-colors duration-500 overflow-x-hidden bg-brand-50 dark:bg-slate-950">
      <div className={`fixed inset-0 bg-slate-950/40 backdrop-blur-md z-[100] transition-opacity duration-500 md:hidden ${isMobileMenuOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} onClick={toggleMobileMenu} />
      
      <aside className={`fixed top-0 left-0 bottom-0 w-[80%] max-w-[320px] bg-white dark:bg-slate-900 z-[101] transition-transform duration-500 cubic-bezier(0.4, 0, 0.2, 1) shadow-[40px_0_60px_-15px_rgba(0,0,0,0.1)] md:hidden flex flex-col ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}`}>
          <div className="p-8 border-b border-slate-100 dark:border-white/5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-brand-600 rounded-xl flex items-center justify-center shadow-ontrack">
                    <Activity className="w-6 h-6 text-white" />
                  </div>
                  <span className="text-2xl font-black font-display text-slate-950 dark:text-white tracking-tighter leading-none">OnTrack</span>
              </div>
              <button onClick={toggleMobileMenu} className="p-2 text-slate-400 hover:text-slate-900 dark:hover:text-white transition-colors"><X className="w-6 h-6" /></button>
          </div>
          <div className="p-6 space-y-2.5 flex-1 overflow-y-auto scrollbar-hide">
              {navItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => handleNavClick(item.id)}
                    className={`w-full px-6 py-4.5 rounded-2xl text-[14px] font-black tracking-tight transition-all flex items-center gap-4 ${
                      currentView === item.id 
                        ? 'bg-brand-600 text-white shadow-ontrack scale-[1.02]' 
                        : 'text-slate-500 dark:text-slate-400 hover:bg-brand-50 dark:hover:bg-white/5'
                    }`}
                  >
                    <item.icon className="w-5 h-5" />
                    {item.label}
                  </button>
              ))}
          </div>
          <div className="p-8 border-t border-slate-100 dark:border-white/5 bg-slate-50/50 dark:bg-slate-950/20">
              <div onClick={() => handleNavClick(AppView.PROFILE)} className="flex items-center gap-4 cursor-pointer p-4 rounded-2xl hover:bg-white dark:hover:bg-white/5 shadow-sm transition-all group">
                  <div className="w-12 h-12 rounded-xl border-2 border-brand-600/10 dark:border-white/10 p-0.5 group-hover:scale-110 transition-transform">
                    <img src={`https://api.dicebear.com/9.x/avataaars/svg?seed=${user.name}`} className="w-full h-full rounded-lg bg-white" alt="User" />
                  </div>
                  <div className="min-w-0">
                      <p className="text-sm font-black text-slate-950 dark:text-white truncate">{user.name}</p>
                      <p className="text-[10px] text-brand-600 dark:text-brand-400 font-black uppercase tracking-widest">{user.type}</p>
                  </div>
              </div>
          </div>
      </aside>

      <nav className="glass-morphism sticky top-0 z-[60] border-b border-slate-100 dark:border-white/5 bg-white/95 dark:bg-slate-900/95 shadow-premium">
        <div className="max-w-7xl mx-auto px-4 sm:px-8">
          <div className="flex items-center justify-between h-20 sm:h-24">
            <div className="flex items-center gap-6 sm:gap-12">
              <button onClick={toggleMobileMenu} className="md:hidden p-3 text-slate-600 dark:text-slate-400 hover:bg-brand-50 rounded-2xl transition-all shadow-sm">
                  <Menu className="w-6 h-6" />
              </button>
              <div className="flex-shrink-0 cursor-pointer flex items-center gap-3 group" onClick={() => onChangeView(AppView.DASHBOARD)}>
                 <div className="w-9 h-9 sm:w-11 sm:h-11 bg-brand-600 rounded-xl flex items-center justify-center shadow-ontrack group-hover:scale-110 group-hover:rotate-6 transition-all duration-500">
                    <Activity className="w-6 h-6 text-white" />
                 </div>
                 <span className="text-xl sm:text-2xl font-black font-display text-slate-950 dark:text-white tracking-tighter">
                    On<span className="text-brand-600">Track</span>
                 </span>
              </div>
              <div className="hidden md:flex space-x-1">
                {navItems.map((item) => (
                    <button
                      key={item.id}
                      onClick={() => onChangeView(item.id)}
                      className={`px-5 py-2.5 rounded-xl text-[13px] font-black uppercase tracking-tight transition-all duration-300 flex items-center gap-2.5 ${
                        currentView === item.id 
                          ? 'bg-brand-600 text-white shadow-ontrack' 
                          : 'text-slate-500 dark:text-slate-400 hover:text-brand-600 hover:bg-brand-50 dark:hover:bg-white/5'
                      }`}
                    >
                      <item.icon className={`w-4 h-4 transition-transform duration-500 ${currentView === item.id ? 'scale-110' : ''}`} />
                      {item.label}
                    </button>
                  ))}
              </div>
            </div>
            <div className="flex items-center gap-3 sm:gap-6">
               <div className="hidden xl:flex items-center gap-2.5 px-4 py-2 bg-emerald-50 dark:bg-emerald-500/10 rounded-2xl border border-emerald-100 dark:border-emerald-500/20 shadow-sm">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-[10px] font-black text-emerald-700 dark:text-emerald-400 uppercase tracking-[0.1em]">INTELLIGENCE: SYNCED</span>
               </div>
               
               <div className="flex items-center gap-2">
                  <button 
                    onClick={toggleFullscreen}
                    className="p-2.5 rounded-xl bg-brand-50 dark:bg-slate-800/50 border border-brand-100 dark:border-white/5 text-slate-500 dark:text-slate-400 hover:text-brand-600 dark:hover:text-white transition-all shadow-sm group"
                    title={isFullscreen ? "Exit Fullscreen" : "Enter Fullscreen"}
                  >
                    {isFullscreen ? <Minimize className="w-4.5 h-4.5 group-active:scale-90 transition-transform" /> : <Maximize className="w-4.5 h-4.5 group-active:scale-110 transition-transform" />}
                  </button>
                  <ThemeToggle isDarkMode={isDarkMode} onToggle={onToggleTheme} />
               </div>

               <div className="hidden lg:flex bg-brand-50 dark:bg-slate-800/50 px-4 py-2.5 rounded-2xl border border-brand-100 dark:border-white/5 items-center gap-3 shadow-sm hover:scale-105 transition-transform">
                  <Zap className="w-4.5 h-4.5 text-gold fill-current drop-shadow-sm" />
                  <span className="text-[13px] font-black text-slate-900 dark:text-white tracking-tight">{user.loyaltyPoints.toLocaleString()} pts</span>
               </div>
               <div onClick={() => onChangeView(AppView.PROFILE)} className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl border-2 border-slate-200 dark:border-white/10 shadow-premium overflow-hidden cursor-pointer hover:border-brand-600 hover:scale-105 transition-all bg-white dark:bg-slate-800 p-0.5">
                    <img src={`https://api.dicebear.com/9.x/avataaars/svg?seed=${user.name}`} alt="Avatar" className="w-full h-full rounded-xl" />
               </div>
            </div>
          </div>
        </div>
      </nav>

      <div className="flex flex-1 relative min-h-[calc(100vh-6rem)]">
        <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-8 py-8 md:py-12 transition-all duration-700">
          {children}
        </main>
        
        {/* Chat Drawer Overlay */}
        <div className={`fixed bottom-24 right-4 sm:bottom-28 sm:right-10 w-[calc(100%-2rem)] sm:w-[480px] h-[780px] max-h-[calc(100vh-12rem)] z-[100] transition-all duration-700 cubic-bezier(0.34, 1.56, 0.64, 1) origin-bottom-right ${isChatOpen ? 'scale-100 opacity-100 translate-y-0 rotate-0' : 'scale-90 opacity-0 translate-y-20 rotate-3 pointer-events-none'}`}>
          <div className="h-full bg-white dark:bg-slate-950 rounded-[3rem] border border-brand-100 dark:border-white/10 shadow-[0_30px_100px_-20px_rgba(79,70,229,0.25)] flex flex-col overflow-hidden ring-1 ring-black/5 dark:ring-white/5">
            <ChatAssistant user={user} onClose={toggleChat} />
          </div>
        </div>

        {/* Floating Chat Trigger */}
        <button 
          onClick={toggleChat} 
          className={`fixed bottom-8 right-8 md:bottom-12 md:right-12 w-16 h-16 md:w-20 md:h-20 rounded-[2rem] z-[101] shadow-ontrack flex items-center justify-center transition-all duration-500 hover:scale-110 active:scale-90 border-4 border-white dark:border-slate-950 group ${isChatOpen ? 'bg-slate-950 text-white dark:bg-white dark:text-slate-950 rotate-90' : 'bg-brand-600 text-white shadow-soft-glow'}`}
        >
          {isChatOpen ? <X className="w-8 h-8" /> : <MessageSquare className="w-8 h-8 group-hover:animate-float" />}
          {!isChatOpen && (
             <span className="absolute -top-1 -right-1 w-6 h-6 bg-rose-500 rounded-full border-4 border-white dark:border-slate-950 flex items-center justify-center">
                <span className="w-2 h-2 bg-white rounded-full animate-ping"></span>
             </span>
          )}
        </button>
      </div>
    </div>
  );
};

export default Layout;