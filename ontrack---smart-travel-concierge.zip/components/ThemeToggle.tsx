
import React from 'react';
import { Sun, Moon } from 'lucide-react';

interface ThemeToggleProps {
  isDarkMode: boolean;
  onToggle: () => void;
  className?: string;
}

const ThemeToggle: React.FC<ThemeToggleProps> = ({ isDarkMode, onToggle, className = "" }) => {
  return (
    <button
      onClick={onToggle}
      className={`relative inline-flex h-9 w-16 items-center rounded-full transition-all duration-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 shadow-sm border ${
        isDarkMode 
          ? 'bg-slate-800 border-white/5' 
          : 'bg-indigo-50 border-indigo-100'
      } ${className}`}
      title={isDarkMode ? "Switch to Studio Light" : "Switch to Elite Dark"}
    >
      <span className="sr-only">Toggle Theme</span>
      <span
        className={`inline-block h-7 w-7 transform rounded-full bg-white shadow-premium transition-transform duration-500 flex items-center justify-center ${
          isDarkMode ? 'translate-x-8' : 'translate-x-1'
        }`}
      >
        {isDarkMode ? (
          <Moon className="w-4 h-4 text-indigo-600" />
        ) : (
          <Sun className="w-4 h-4 text-amber-500" />
        )}
      </span>
      <div className="absolute inset-0 flex justify-between px-2 items-center pointer-events-none opacity-40">
        <Sun className={`w-3.5 h-3.5 transition-opacity ${isDarkMode ? 'opacity-100' : 'opacity-0'}`} />
        <Moon className={`w-3.5 h-3.5 transition-opacity ${isDarkMode ? 'opacity-0' : 'opacity-100'}`} />
      </div>
    </button>
  );
};

export default ThemeToggle;
