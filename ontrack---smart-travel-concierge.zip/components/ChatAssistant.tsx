import { useState, useEffect, useRef } from 'react';
import { chatWithTravelAssistantStream, generateDailyAudioBriefing } from '../services/geminiService';
import { ChatMessage, UserProfile } from '../types';
import { Send, Sparkles, Bot, MessageSquare, Loader2, Volume2, VolumeX, Copy, CheckCircle2, X, Headphones, MoreHorizontal, Globe } from 'lucide-react';

interface ChatAssistantProps {
    user: UserProfile;
    contextDestination?: string;
    onClose?: () => void;
}

// Audio decoding utilities
function decodePCM(base64: string) {
  const binaryString = atob(base64);
  const bytes = new Uint8Array(binaryString.length);
  for (let i = 0; i < binaryString.length; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(data: Uint8Array, ctx: AudioContext): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const buffer = ctx.createBuffer(1, dataInt16.length, 24000);
  const channelData = buffer.getChannelData(0);
  for (let i = 0; i < dataInt16.length; i++) {
    channelData[i] = dataInt16[i] / 32768.0;
  }
  return buffer;
}

const ChatAssistant: React.FC<ChatAssistantProps> = ({ user, contextDestination, onClose }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    { 
        id: '1', 
        role: 'model', 
        text: contextDestination 
            ? `Hi! I've been monitoring the latest intel for **${contextDestination}**. I've curated some high-fidelity options for your trip. What's our first objective?`
            : "Greeting, explorer. I'm your OnTrack intelligence unit. Ready to synchronize your next journey?", 
        timestamp: new Date() 
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [audioLoadingId, setAudioLoadingId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const currentSourceRef = useRef<AudioBufferSourceNode | null>(null);
  const isAutoScrollingRef = useRef(true);

  const handleScroll = () => {
    if (!scrollContainerRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = scrollContainerRef.current;
    const distanceToBottom = scrollHeight - scrollTop - clientHeight;
    isAutoScrollingRef.current = distanceToBottom < 100;
  };

  useEffect(() => {
    if (isAutoScrollingRef.current) {
      bottomRef.current?.scrollIntoView({ behavior: isTyping ? 'auto' : 'smooth' });
    }
  }, [messages, isTyping]);

  const handleSend = async (text: string) => {
    if (!text.trim()) return;
    stopAudio();

    const userMsg: ChatMessage = { id: Date.now().toString(), role: 'user', text: text, timestamp: new Date() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);
    isAutoScrollingRef.current = true;

    const history = messages.map(m => ({ role: m.role, parts: [{ text: m.text }] }));
    const botMsgId = (Date.now() + 1).toString();
    const tempBotMsg: ChatMessage = { id: botMsgId, role: 'model', text: '', timestamp: new Date() };
    setMessages(prev => [...prev, tempBotMsg]);

    try {
        await chatWithTravelAssistantStream(history, text, user, (chunk) => {
            setMessages(prev => prev.map(m => m.id === botMsgId ? { ...m, text: chunk } : m));
        });
    } catch (error) {
        console.error("Chat Error:", error);
    } finally {
        setIsTyping(false);
    }
  };

  const stopAudio = () => {
    if (currentSourceRef.current) {
        currentSourceRef.current.stop();
        currentSourceRef.current = null;
    }
  };

  const playMessage = async (msgId: string, text: string) => {
    if (audioLoadingId === msgId) {
        stopAudio();
        setAudioLoadingId(null);
        return;
    }
    stopAudio();
    setAudioLoadingId(msgId);
    try {
        const base64 = await generateDailyAudioBriefing(text, user.persona);
        const ctx = audioContextRef.current || new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        audioContextRef.current = ctx;
        const decodedBytes = decodePCM(base64);
        const buffer = await decodeAudioData(decodedBytes, ctx);
        const source = ctx.createBufferSource();
        source.buffer = buffer;
        source.connect(ctx.destination);
        source.onended = () => setAudioLoadingId(null);
        source.start(0);
        currentSourceRef.current = source;
    } catch (e) {
        setAudioLoadingId(null);
    }
  };

  const copyToClipboard = (id: string, text: string) => {
      navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
  };

  const renderMessageContent = (content: string) => {
      if (!content) return <span className="inline-block w-2 h-5 bg-brand-600 dark:bg-gold animate-pulse ml-1" />;
      const lines = content.split('\n');
      return lines.map((line, lIdx) => {
          const parts = line.split(/(\*\*.*?\*\*)/g);
          return (
            <div key={lIdx} className={lIdx > 0 ? "mt-3" : ""}>
                {parts.map((part, pIdx) => {
                    if (part.startsWith('**') && part.endsWith('**')) {
                        return <strong key={pIdx} className="text-slate-950 dark:text-gold font-extrabold tracking-tight">{part.slice(2, -2)}</strong>;
                    }
                    return part;
                })}
            </div>
          );
      });
  };

  return (
    <div className="flex flex-col h-full overflow-hidden bg-white dark:bg-slate-950 transition-colors">
        {/* Luxury Header */}
        <header className="px-8 py-7 flex items-center justify-between border-b border-brand-50 dark:border-white/5 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl z-20">
            <div className="flex items-center gap-5">
                <div className="relative">
                    <div className="w-14 h-14 bg-brand-600 rounded-[1.25rem] flex items-center justify-center shadow-ontrack animate-pulse-slow">
                        <Bot className="w-7 h-7 text-white" />
                    </div>
                    <div className="absolute -bottom-1 -right-1 w-5 h-5 bg-emerald-500 rounded-full border-4 border-white dark:border-slate-900 shadow-sm" />
                </div>
                <div>
                    <h3 className="font-black text-slate-950 dark:text-white text-lg leading-tight tracking-tighter">Concierge Core</h3>
                    <div className="flex items-center gap-2 mt-1">
                        <span className="text-[10px] text-brand-600 dark:text-slate-400 font-black uppercase tracking-[0.2em]">{user.persona} synchronization active</span>
                    </div>
                </div>
            </div>
            <div className="flex items-center gap-2">
                <button className="p-3 text-slate-400 hover:text-brand-600 dark:hover:text-white transition-all rounded-xl hover:bg-brand-50/50">
                    <MoreHorizontal className="w-6 h-6" />
                </button>
                <button 
                    onClick={onClose}
                    className="p-3 text-slate-400 hover:text-rose-500 transition-all rounded-xl hover:bg-rose-50/50"
                >
                    <X className="w-6 h-6" />
                </button>
            </div>
        </header>

        {/* Message Container */}
        <div 
          ref={scrollContainerRef}
          onScroll={handleScroll}
          className="flex-1 overflow-y-auto p-8 space-y-10 scrollbar-hide bg-brand-50/20 dark:bg-transparent"
        >
            {messages.map((msg) => (
                <div key={msg.id} className={`flex w-full ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-fade-in`}>
                    <div className={`flex flex-col max-w-[88%] ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                        <div className={`
                            relative group px-7 py-5 rounded-[2.25rem] shadow-sm text-[15px] sm:text-[16px] leading-relaxed transition-all duration-500
                            ${msg.role === 'user' 
                                ? 'bg-brand-600 text-white rounded-tr-none shadow-ontrack' 
                                : 'bg-white dark:bg-slate-800/80 text-slate-800 dark:text-slate-100 border border-slate-100 dark:border-white/5 rounded-tl-none font-medium'}
                        `}>
                            {renderMessageContent(msg.text)}

                            {msg.role === 'model' && msg.text && (
                                <div className="flex items-center gap-2 mt-5 pt-5 border-t border-slate-100 dark:border-white/5 opacity-0 group-hover:opacity-100 transition-all">
                                    <button onClick={() => playMessage(msg.id, msg.text)} className="p-2.5 hover:bg-brand-50 dark:hover:bg-white/10 rounded-xl text-brand-500 dark:text-slate-400 transition-colors" title="Listen">
                                        {audioLoadingId === msg.id ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
                                    </button>
                                    <button onClick={() => copyToClipboard(msg.id, msg.text)} className="p-2.5 hover:bg-brand-50 dark:hover:bg-white/10 rounded-xl text-brand-500 dark:text-slate-400 transition-colors" title="Copy">
                                        {copiedId === msg.id ? <CheckCircle2 className="w-5 h-5 text-emerald-500" /> : <Copy className="w-5 h-5" />}
                                    </button>
                                </div>
                            )}
                        </div>
                        <div className="flex items-center gap-2 mt-3 px-3">
                            <span className="text-[10px] font-black text-brand-400 dark:text-slate-500 uppercase tracking-widest">
                                {msg.role === 'user' ? 'Traveler' : 'Core'}
                            </span>
                            <div className="w-1 h-1 rounded-full bg-slate-200 dark:bg-slate-700" />
                            <span className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest">
                                {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                        </div>
                    </div>
                </div>
            ))}

            {isTyping && (
                <div className="flex justify-start animate-fade-in">
                    <div className="bg-white dark:bg-slate-800/80 px-8 py-5 rounded-[2.25rem] rounded-tl-none border border-slate-100 dark:border-white/5 shadow-sm">
                        <div className="flex gap-2.5 items-center">
                            <div className="w-2.5 h-2.5 bg-brand-600 dark:bg-gold rounded-full animate-bounce [animation-delay:-0.3s]" />
                            <div className="w-2.5 h-2.5 bg-brand-600 dark:bg-gold rounded-full animate-bounce [animation-delay:-0.15s]" />
                            <div className="w-2.5 h-2.5 bg-brand-600 dark:bg-gold rounded-full animate-bounce" />
                        </div>
                    </div>
                </div>
            )}
            <div ref={bottomRef} className="h-4" />
        </div>

        {/* Tactical Footer */}
        <footer className="p-8 border-t border-slate-100 dark:border-white/5 bg-white dark:bg-slate-950 z-30">
            <div className="flex gap-2.5 overflow-x-auto pb-7 scrollbar-hide">
                {["Tactical Re-route", "Dining Intel", "Safety Status", "Local Gems"].map((s, i) => (
                    <button 
                        key={i} 
                        onClick={() => handleSend(s)}
                        className="whitespace-nowrap px-6 py-3 bg-brand-50/50 dark:bg-white/5 hover:bg-brand-600 hover:text-white text-[11px] font-black text-brand-600 dark:text-slate-300 rounded-2xl border border-brand-100/30 dark:border-white/5 transition-all shadow-sm"
                    >
                        {s}
                    </button>
                ))}
            </div>

            <form 
                onSubmit={(e) => { e.preventDefault(); handleSend(input); }} 
                className="relative flex items-center gap-5"
            >
                <div className="relative flex-1 group">
                    <input 
                        type="text"
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        placeholder="Uplink message..."
                        className="w-full bg-slate-50/80 dark:bg-white/5 text-slate-950 dark:text-white rounded-[1.75rem] pl-7 pr-16 py-5.5 focus:outline-none focus:ring-4 focus:ring-brand-600/5 dark:focus:ring-gold/5 border border-transparent transition-all text-[15px] sm:text-[16px] font-semibold shadow-inner"
                    />
                    <div className="absolute right-6 top-1/2 -translate-y-1/2">
                        <Sparkles className="w-6 h-6 text-brand-300 dark:text-slate-600 group-focus-within:text-brand-600 transition-colors" />
                    </div>
                </div>
                
                <button 
                    type="submit"
                    disabled={!input.trim() || isTyping}
                    className="bg-brand-600 dark:bg-white text-white dark:text-slate-950 w-16 h-16 sm:w-18 sm:h-18 rounded-[1.75rem] shadow-ontrack flex items-center justify-center hover:bg-brand-700 dark:hover:bg-slate-100 disabled:opacity-30 disabled:shadow-none active:scale-90 transition-all shrink-0"
                >
                    {isTyping ? <Loader2 className="w-7 h-7 animate-spin" /> : <Send className="w-8 h-8" />}
                </button>
            </form>
            
            <div className="mt-7 flex justify-center">
                <div className="flex items-center gap-3 px-5 py-2 bg-emerald-50/50 dark:bg-emerald-500/5 rounded-full border border-emerald-100/50 dark:border-emerald-500/10">
                    <Globe className="w-3.5 h-3.5 text-emerald-500" />
                    <span className="text-[10px] font-black text-emerald-600 dark:text-emerald-400 uppercase tracking-widest">Secure Neural Uplink</span>
                </div>
            </div>
        </footer>
    </div>
  );
};

export default ChatAssistant;